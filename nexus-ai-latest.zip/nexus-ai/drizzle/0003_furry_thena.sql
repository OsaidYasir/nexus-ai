CREATE TABLE `mediaItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('image','video') NOT NULL,
	`source` enum('generated','uploaded') NOT NULL,
	`prompt` text,
	`url` text NOT NULL,
	`thumbnailUrl` text,
	`fileKey` varchar(512) NOT NULL,
	`mimeType` varchar(128) NOT NULL,
	`size` int NOT NULL DEFAULT 0,
	`filename` varchar(255),
	`style` varchar(64),
	`aspectRatio` varchar(16),
	`status` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'completed',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mediaItems_id` PRIMARY KEY(`id`)
);
