# Nexus AI — Autonomous Agent Platform

> A full-stack AI agent platform with real-time streaming, autonomous task execution, media generation, and a premium dark UI. Built with React 19, tRPC, Drizzle ORM, and a custom agent loop engine.

---

## Live Demo

Deployed at: [nexusai-h4sru7e3.manus.space](https://nexusai-h4sru7e3.manus.space)

---

## Features

### Core Agent Capabilities
- **Autonomous Agent Loop** — LLM-powered reasoning engine that breaks down complex goals into steps and executes them independently
- **6 Built-in Tools** — Web Search, Code Execution, File Read/Write, Data Analysis, Plan Creation
- **Real-time SSE Streaming** — Agent thinking steps and responses stream live as they happen
- **Self-correction & Reflection** — Agent evaluates its own output and retries on failure

### Chat Interface
- Conversational chat with full message history and markdown rendering
- Streaming responses with live typing indicator
- Collapsible reasoning/thinking panels per message
- Image and video attachment support in messages
- Conversation search, rename, and archive

### Task Management
- Create and execute autonomous multi-step tasks
- Live step-by-step execution visualization
- Pause, cancel, and retry task controls
- Full execution logs with timing data

### Media Studio
- **AI Image Generation** — 6 styles (Photorealistic, Digital Art, Oil Painting, Watercolor, Sketch, Anime), 5 aspect ratios, image-to-image editing
- **AI Video Concept Generation** — LLM-enhanced keyframe and storyboard generation
- **User Media Upload** — Drag-and-drop image and video upload with S3 storage
- Full media gallery with lightbox viewer

### Platform
- Tool configuration interface — enable/disable and configure agent tools
- Agent memory management — persistent knowledge across sessions
- File management with S3 storage integration
- Admin dashboard with platform stats and user management
- Settings page — profile, appearance, agent config, notifications, security
- Role-based access control (admin / user)

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 19, Tailwind CSS 4, Framer Motion, shadcn/ui |
| Backend | Node.js, Express 4, tRPC 11 |
| Database | MySQL / TiDB via Drizzle ORM |
| Auth | Manus OAuth (JWT sessions) |
| Storage | AWS S3 |
| AI | Built-in LLM API (OpenAI-compatible) |
| Testing | Vitest (13 tests) |
| Build | Vite 7, esbuild, TypeScript 5.9 |

---

## Project Structure

```
nexus-ai/
├── client/
│   └── src/
│       ├── pages/          # Chat, Tasks, Tools, Memory, Files, MediaStudio, Admin, Settings
│       ├── components/     # DashboardLayout, AIChatBox, shadcn/ui components
│       ├── hooks/          # useAuth, useMobile
│       └── lib/trpc.ts     # tRPC client binding
├── server/
│   ├── agent.ts            # Core autonomous agent loop engine
│   ├── stream.ts           # SSE streaming endpoint
│   ├── routers.ts          # All tRPC procedures
│   ├── db.ts               # Database query helpers
│   ├── storage.ts          # S3 file storage helpers
│   └── _core/              # Auth, LLM, OAuth, context (framework-level)
├── drizzle/
│   └── schema.ts           # Database tables: users, conversations, messages, tasks, tools, memory, files, media
└── shared/                 # Shared types and constants
```

---

## Getting Started

### Prerequisites
- Node.js 22+
- pnpm 10+
- MySQL / TiDB database

### Installation

```bash
git clone https://github.com/YOUR_USERNAME/nexus-ai.git
cd nexus-ai
pnpm install
```

### Environment Variables

Copy `.env.example` to `.env` and fill in the required values:

```env
DATABASE_URL=mysql://user:password@host:port/dbname
JWT_SECRET=your-jwt-secret
BUILT_IN_FORGE_API_KEY=your-llm-api-key
BUILT_IN_FORGE_API_URL=https://your-llm-api-url
```

### Database Setup

```bash
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

### Development

```bash
pnpm dev
```

The app will be available at `http://localhost:3000`.

### Testing

```bash
pnpm test
```

---

## Roadmap

- [ ] Real web search API integration (Tavily / Serper)
- [ ] Real code execution sandbox (E2B / Piston)
- [ ] Voice input with Whisper transcription
- [ ] Conversation export (PDF / Markdown)
- [ ] Multi-agent collaboration
- [ ] Plugin marketplace for custom tools

---

## License

MIT — free to use, modify, and distribute.
