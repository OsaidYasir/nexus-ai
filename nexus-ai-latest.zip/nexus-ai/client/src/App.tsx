import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import DashboardLayout from "./components/DashboardLayout";
import Home from "./pages/Home";
import Chat from "./pages/Chat";
import Tasks from "./pages/Tasks";
import Tools from "./pages/Tools";
import Memory from "./pages/Memory";
import Files from "./pages/Files";
import Admin from "./pages/Admin";
import Settings from "./pages/Settings";
import MediaStudio from "./pages/MediaStudio";

function Router() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/chat" component={Chat} />
        <Route path="/chat/:id" component={Chat} />
        <Route path="/tasks" component={Tasks} />
        <Route path="/tools" component={Tools} />
        <Route path="/memory" component={Memory} />
        <Route path="/files" component={Files} />
        <Route path="/admin" component={Admin} />
        <Route path="/settings" component={Settings} />
        <Route path="/media" component={MediaStudio} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
