import { trpc } from "@/lib/trpc";
import { motion, AnimatePresence } from "framer-motion";
import {
  ListTodo, Plus, Play, X, ChevronRight, Clock,
  CheckCircle2, XCircle, Loader2, AlertCircle, Sparkles,
  Globe, Code, FileText, BarChart2, ClipboardList, Zap,
  Search, MoreHorizontal, Trash2, Brain,
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { Streamdown } from "streamdown";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

const toolIcons: Record<string, React.ElementType> = {
  web_search: Globe, execute_code: Code, read_file: FileText,
  write_file: FileText, analyze_data: BarChart2, create_plan: ClipboardList,
  think: Brain, plan: ClipboardList, reflection: Brain,
};

const statusConfig: Record<string, { icon: React.ElementType; color: string; bg: string; label: string }> = {
  pending: { icon: Clock, color: "text-muted-foreground", bg: "bg-muted/50", label: "Pending" },
  planning: { icon: Brain, color: "text-blue-400", bg: "bg-blue-500/10", label: "Planning" },
  running: { icon: Loader2, color: "text-blue-400", bg: "bg-blue-500/10", label: "Running" },
  completed: { icon: CheckCircle2, color: "text-green-400", bg: "bg-green-500/10", label: "Completed" },
  failed: { icon: XCircle, color: "text-destructive", bg: "bg-destructive/10", label: "Failed" },
  cancelled: { icon: X, color: "text-muted-foreground", bg: "bg-muted/50", label: "Cancelled" },
};

const priorityConfig: Record<string, { color: string; dot: string; label: string }> = {
  low: { color: "text-muted-foreground", dot: "bg-muted-foreground", label: "Low" },
  medium: { color: "text-yellow-400", dot: "bg-yellow-400", label: "Medium" },
  high: { color: "text-orange-400", dot: "bg-orange-400", label: "High" },
  critical: { color: "text-destructive", dot: "bg-destructive", label: "Critical" },
};

function TaskCard({ task, onExecute, onCancel, onDelete }: {
  task: any; onExecute: (id: number) => void;
  onCancel: (id: number) => void; onDelete: (id: number) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const { data: steps } = trpc.tasks.steps.useQuery({ taskId: task.id }, { enabled: expanded });

  const status = statusConfig[task.status] || statusConfig.pending;
  const priority = priorityConfig[task.priority] || priorityConfig.medium;
  const StatusIcon = status.icon;

  return (
    <motion.div layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border/50 rounded-xl overflow-hidden hover:border-border transition-all"
    >
      <div className="p-4">
        <div className="flex items-start gap-3">
          <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${status.bg}`}>
            <StatusIcon className={`h-4 w-4 ${status.color} ${task.status === "running" || task.status === "planning" ? "animate-spin" : ""}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <h3 className="text-sm font-semibold text-foreground">{task.title}</h3>
              <div className="flex items-center gap-1">
                <div className={`h-1.5 w-1.5 rounded-full ${priority.dot}`} />
                <span className={`text-xs ${priority.color}`}>{priority.label}</span>
              </div>
            </div>
            {task.description && <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{task.description}</p>}
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className={`font-medium ${status.color}`}>{status.label}</span>
              {task.durationMs && <span className="flex items-center gap-1"><Clock className="h-2.5 w-2.5" />{(task.durationMs / 1000).toFixed(1)}s</span>}
              <span className="ml-auto">{new Date(task.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            {(task.status === "pending" || task.status === "failed") && (
              <Button size="sm" variant="outline" className="h-7 px-2 text-xs gap-1" onClick={() => onExecute(task.id)}>
                <Play className="h-3 w-3" />Run
              </Button>
            )}
            {(task.status === "running" || task.status === "planning") && (
              <Button size="sm" variant="outline" className="h-7 px-2 text-xs gap-1 text-destructive border-destructive/30" onClick={() => onCancel(task.id)}>
                <X className="h-3 w-3" />Stop
              </Button>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="h-7 w-7 rounded flex items-center justify-center hover:bg-accent transition-colors">
                  <MoreHorizontal className="h-4 w-4 text-muted-foreground" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                <DropdownMenuItem onClick={() => setExpanded(!expanded)}>
                  <ChevronRight className="h-4 w-4 mr-2" />{expanded ? "Hide" : "View"} Steps
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onDelete(task.id)} className="text-destructive focus:text-destructive">
                  <Trash2 className="h-4 w-4 mr-2" />Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        {task.result && task.status === "completed" && (
          <div className="mt-3 pt-3 border-t border-border/50">
            <p className="text-xs text-muted-foreground mb-1.5 font-medium flex items-center gap-1.5">
              <CheckCircle2 className="h-3 w-3 text-green-400" />Result
            </p>
            <div className="text-xs prose-nexus bg-muted/30 rounded-lg p-3 max-h-40 overflow-y-auto custom-scrollbar">
              <Streamdown>{task.result}</Streamdown>
            </div>
          </div>
        )}
        {task.errorMessage && task.status === "failed" && (
          <div className="mt-3 pt-3 border-t border-border/50">
            <div className="flex items-center gap-2 text-xs text-destructive bg-destructive/5 rounded-lg p-2">
              <AlertCircle className="h-3.5 w-3.5 shrink-0" /><span>{task.errorMessage}</span>
            </div>
          </div>
        )}
      </div>
      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden border-t border-border/50"
          >
            <div className="p-4 space-y-2 bg-muted/10">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Execution Steps</p>
              {!steps || steps.length === 0 ? (
                <p className="text-xs text-muted-foreground py-2 text-center">No steps recorded yet</p>
              ) : (
                (steps as any[]).map((step: any, i: number) => {
                  const Icon = toolIcons[step.toolName || step.type || ""] || Zap;
                  const ss = statusConfig[step.status] || statusConfig.pending;
                  const StepStatusIcon = ss.icon;
                  return (
                    <motion.div key={step.id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.04 }}
                      className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-card border border-border/40"
                    >
                      <StepStatusIcon className={`h-3 w-3 shrink-0 ${ss.color}`} />
                      <Icon className="h-3 w-3 shrink-0 text-primary/60" />
                      <span className="text-xs text-foreground flex-1 truncate">{step.title}</span>
                      {step.durationMs && <span className="text-xs text-muted-foreground">{step.durationMs}ms</span>}
                    </motion.div>
                  );
                })
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function Tasks() {
  const [showCreate, setShowCreate] = useState(false);
  const [newTask, setNewTask] = useState({ title: "", description: "", priority: "medium" as const });
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");

  const { data: tasks, isLoading, refetch } = trpc.tasks.list.useQuery();
  const createTask = trpc.tasks.create.useMutation({
    onSuccess: () => { refetch(); setShowCreate(false); setNewTask({ title: "", description: "", priority: "medium" }); toast.success("Task created!"); },
    onError: (e) => toast.error(e.message),
  });
  const executeTask = trpc.tasks.execute.useMutation({
    onSuccess: () => { refetch(); toast.success("Task completed!"); },
    onError: (e) => { refetch(); toast.error(e.message); },
  });
  const cancelTask = trpc.tasks.cancel.useMutation({ onSuccess: () => refetch() });

  const allTasks = (tasks || []) as any[];
  const filteredTasks = allTasks
    .filter(t => filter === "all" || t.status === filter)
    .filter(t => !search || t.title.toLowerCase().includes(search.toLowerCase()));

  const counts: Record<string, number> = {
    all: allTasks.length,
    pending: allTasks.filter(t => t.status === "pending").length,
    running: allTasks.filter(t => t.status === "running" || t.status === "planning").length,
    completed: allTasks.filter(t => t.status === "completed").length,
    failed: allTasks.filter(t => t.status === "failed").length,
  };

  return (
    <div className="h-full flex flex-col">
      <div className="border-b border-border/50 px-6 py-4 flex items-center justify-between shrink-0 bg-background/80 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <ListTodo className="h-4 w-4 text-primary" />
          </div>
          <div>
            <h1 className="text-base font-semibold text-foreground">Tasks</h1>
            <p className="text-xs text-muted-foreground">{allTasks.length} total · {counts.running} running</p>
          </div>
        </div>
        <Button onClick={() => setShowCreate(true)} size="sm" className="gap-1.5">
          <Plus className="h-3.5 w-3.5" />New Task
        </Button>
      </div>

      <div className="px-6 py-3 border-b border-border/50 flex items-center gap-3 shrink-0 flex-wrap">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search tasks..."
            className="h-8 pl-8 pr-3 text-xs bg-muted/50 border border-border/50 rounded-lg focus:outline-none focus:ring-1 focus:ring-ring text-foreground placeholder:text-muted-foreground w-48"
          />
        </div>
        <div className="flex items-center gap-1 flex-wrap">
          {(["all", "pending", "running", "completed", "failed"] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filter === f ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-accent/50"}`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
              {counts[f] > 0 && <span className="ml-1.5 opacity-60">{counts[f]}</span>}
            </button>
          ))}
        </div>
      </div>

      <ScrollArea className="flex-1 custom-scrollbar">
        <div className="p-6 space-y-3">
          {isLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-24 rounded-xl bg-muted/30 animate-pulse" />
            ))
          ) : filteredTasks.length === 0 ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-16 gap-4"
            >
              <div className="h-14 w-14 rounded-2xl bg-muted/50 flex items-center justify-center">
                <ListTodo className="h-7 w-7 text-muted-foreground/40" />
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-foreground mb-1">No tasks found</p>
                <p className="text-xs text-muted-foreground">Create a task and let the agent execute it autonomously</p>
              </div>
              <Button onClick={() => setShowCreate(true)} size="sm" variant="outline" className="gap-2">
                <Plus className="h-3.5 w-3.5" />Create your first task
              </Button>
            </motion.div>
          ) : (
            filteredTasks.map(task => (
              <TaskCard key={task.id} task={task}
                onExecute={id => executeTask.mutate({ id })}
                onCancel={id => cancelTask.mutate({ id })}
                onDelete={id => cancelTask.mutate({ id })}
              />
            ))
          )}
        </div>
      </ScrollArea>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />Create New Task
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Task Title *</label>
              <Input value={newTask.title} onChange={e => setNewTask(p => ({ ...p, title: e.target.value }))}
                placeholder="e.g., Research competitors and write a report" className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Description</label>
              <Textarea value={newTask.description} onChange={e => setNewTask(p => ({ ...p, description: e.target.value }))}
                placeholder="Provide detailed instructions for the agent..." className="text-sm min-h-[80px] resize-none"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Priority</label>
              <Select value={newTask.priority} onValueChange={v => setNewTask(p => ({ ...p, priority: v as any }))}>
                <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button onClick={() => createTask.mutate(newTask)} disabled={!newTask.title.trim() || createTask.isPending} className="gap-2">
              {createTask.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
              Create Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
