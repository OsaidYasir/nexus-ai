import { trpc } from "@/lib/trpc";
import { motion, AnimatePresence } from "framer-motion";
import {
  Brain, Plus, Trash2, Search, Tag, Clock, Sparkles,
  Loader2, BookOpen, Lightbulb, Database, X,
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";

const typeConfig: Record<string, { icon: React.ElementType; color: string; bg: string; label: string }> = {
  fact: { icon: BookOpen, color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20", label: "Fact" },
  preference: { icon: Sparkles, color: "text-purple-400", bg: "bg-purple-500/10 border-purple-500/20", label: "Preference" },
  behavior: { icon: Lightbulb, color: "text-yellow-400", bg: "bg-yellow-500/10 border-yellow-500/20", label: "Behavior" },
  context: { icon: Database, color: "text-cyan-400", bg: "bg-cyan-500/10 border-cyan-500/20", label: "Context" },
};

export default function Memory() {
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [newMem, setNewMem] = useState({ key: "", value: "", type: "fact" as "fact" | "preference" | "behavior" | "context" });

  const { data: memories, refetch, isLoading } = trpc.memory.list.useQuery();
  const addMem = trpc.memory.add.useMutation({
    onSuccess: () => { refetch(); setShowAdd(false); setNewMem({ key: "", value: "", type: "fact" }); toast.success("Memory stored!"); },
    onError: (e: any) => toast.error(e.message),
  });
  const deleteMem = trpc.memory.delete.useMutation({
    onSuccess: () => { refetch(); toast.success("Memory deleted"); },
  });

  const allMems = (memories || []) as any[];
  const filtered = allMems
    .filter(m => filterType === "all" || m.type === filterType)
    .filter(m => !search || m.key.toLowerCase().includes(search.toLowerCase()) || m.value.toLowerCase().includes(search.toLowerCase()));

  const counts = {
    all: allMems.length,
    fact: allMems.filter(m => m.type === "fact").length,
    preference: allMems.filter(m => m.type === "preference").length,
    behavior: allMems.filter(m => m.type === "behavior").length,
    context: allMems.filter(m => m.type === "context").length,
  } as Record<string, number>;

  return (
    <div className="h-full flex flex-col">
      <div className="border-b border-border/50 px-6 py-4 flex items-center justify-between shrink-0 bg-background/80 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center"><Brain className="h-4 w-4 text-primary" /></div>
          <div><h1 className="text-base font-semibold text-foreground">Agent Memory</h1><p className="text-xs text-muted-foreground">{allMems.length} memories stored</p></div>
        </div>
        <Button onClick={() => setShowAdd(true)} size="sm" className="gap-1.5"><Plus className="h-3.5 w-3.5" />Add Memory</Button>
      </div>

      <div className="px-6 py-3 border-b border-border/50 flex items-center gap-3 shrink-0 flex-wrap">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search memories..."
            className="h-8 pl-8 pr-3 text-xs bg-muted/50 border border-border/50 rounded-lg focus:outline-none focus:ring-1 focus:ring-ring text-foreground placeholder:text-muted-foreground w-52"
          />
        </div>
        <div className="flex items-center gap-1 flex-wrap">
          {(["all", "fact", "preference", "behavior", "context"] as const).map(f => (
            <button key={f} onClick={() => setFilterType(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filterType === f ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-accent/50"}`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}{counts[f] > 0 && <span className="ml-1.5 opacity-60">{counts[f]}</span>}
            </button>
          ))}
        </div>
      </div>

      <ScrollArea className="flex-1 custom-scrollbar">
        <div className="p-6">
          {isLoading ? (
            <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-20 rounded-xl bg-muted/30 animate-pulse" />)}</div>
          ) : filtered.length === 0 ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center py-16 gap-4">
              <div className="h-14 w-14 rounded-2xl bg-muted/50 flex items-center justify-center"><Brain className="h-7 w-7 text-muted-foreground/40" /></div>
              <div className="text-center">
                <p className="text-sm font-medium text-foreground mb-1">No memories found</p>
                <p className="text-xs text-muted-foreground">Store facts, preferences, and instructions for the agent to remember</p>
              </div>
              <Button onClick={() => setShowAdd(true)} size="sm" variant="outline" className="gap-2"><Plus className="h-3.5 w-3.5" />Add first memory</Button>
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <AnimatePresence>
                {filtered.map((mem: any, i: number) => {
                  const cfg = typeConfig[mem.type] || typeConfig.fact;
                  const Icon = cfg.icon;
                  return (
                    <motion.div key={mem.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ delay: i * 0.03 }}
                      className={`bg-card border rounded-xl p-4 hover:border-border transition-all group ${cfg.bg}`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className={`h-7 w-7 rounded-lg flex items-center justify-center bg-background/60`}><Icon className={`h-3.5 w-3.5 ${cfg.color}`} /></div>
                          <div>
                            <p className="text-sm font-semibold text-foreground">{mem.key}</p>
                            <Badge variant="outline" className={`text-xs border-current/20 ${cfg.color}`}>{cfg.label}</Badge>
                          </div>
                        </div>
                        <button onClick={() => deleteMem.mutate({ id: mem.id })} className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive">
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed mb-3 line-clamp-3">{mem.value}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex flex-wrap gap-1">
                          {mem.importance && <span className="text-xs px-1.5 py-0.5 rounded bg-background/50 border border-border/50 text-muted-foreground flex items-center gap-1"><Tag className="h-2.5 w-2.5" />{mem.importance}</span>}
                        </div>
                        <span className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="h-2.5 w-2.5" />{new Date(mem.createdAt).toLocaleDateString()}</span>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </div>
      </ScrollArea>

      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Brain className="h-4 w-4 text-primary" />Store Memory</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div><label className="text-xs font-medium text-muted-foreground mb-1.5 block">Memory Key *</label><Input value={newMem.key} onChange={e => setNewMem(p => ({ ...p, key: e.target.value }))} placeholder="e.g., user_preference_language" className="h-9 text-sm" /></div>
            <div><label className="text-xs font-medium text-muted-foreground mb-1.5 block">Value *</label><Textarea value={newMem.value} onChange={e => setNewMem(p => ({ ...p, value: e.target.value }))} placeholder="The information to remember..." className="text-sm min-h-[80px] resize-none" /></div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Type</label>
              <Select value={newMem.type} onValueChange={v => setNewMem(p => ({ ...p, type: v as any }))}>
                <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="fact">Fact</SelectItem><SelectItem value="preference">Preference</SelectItem><SelectItem value="behavior">Behavior</SelectItem><SelectItem value="context">Context</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button onClick={() => addMem.mutate({ key: newMem.key, value: newMem.value, type: newMem.type })} disabled={!newMem.key || !newMem.value || addMem.isPending} className="gap-2">
              {addMem.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Brain className="h-3.5 w-3.5" />}Store Memory
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
