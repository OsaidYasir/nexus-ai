import { trpc } from "@/lib/trpc";
import { motion, AnimatePresence } from "framer-motion";
import {
  FolderOpen, Upload, File, FileText, Image, Code, BarChart2,
  Trash2, Download, Search, Grid, List, Clock, Loader2, Plus, X, CheckCircle2,
} from "lucide-react";
import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";

function getFileIcon(mimeType: string) {
  if (!mimeType) return File;
  if (mimeType.startsWith("image/")) return Image;
  if (mimeType.includes("pdf") || mimeType.includes("document")) return FileText;
  if (mimeType.includes("json") || mimeType.includes("javascript")) return Code;
  if (mimeType.includes("csv") || mimeType.includes("spreadsheet")) return BarChart2;
  return File;
}

function formatBytes(bytes: number) {
  if (!bytes || bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

interface UploadItem { id: string; name: string; progress: number; status: "uploading" | "done" | "error"; }

export default function Files() {
  const [view, setView] = useState<"grid" | "list">("list");
  const [search, setSearch] = useState("");
  const [dragging, setDragging] = useState(false);
  const [uploads, setUploads] = useState<UploadItem[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  const { data: files, refetch, isLoading } = trpc.files.list.useQuery();
  const deleteFile = trpc.files.delete.useMutation({ onSuccess: () => { refetch(); toast.success("File deleted"); } });
  const uploadMutation = trpc.files.upload.useMutation({ onSuccess: () => refetch(), onError: (e: any) => toast.error(e.message) });

  const handleFiles = useCallback(async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    for (const file of Array.from(fileList)) {
      if (file.size > 16 * 1024 * 1024) { toast.error(file.name + " exceeds 16MB limit"); continue; }
      const id = Math.random().toString(36).slice(2);
      setUploads(p => [...p, { id, name: file.name, progress: 10, status: "uploading" }]);
      try {
        const reader = new FileReader();
        const dataUrl = await new Promise<string>((res, rej) => {
          reader.onload = () => res(reader.result as string);
          reader.onerror = rej;
          reader.readAsDataURL(file);
        });
        setUploads(p => p.map(u => u.id === id ? { ...u, progress: 70 } : u));
        const base64Data = dataUrl.split(",")[1] || dataUrl;
        await uploadMutation.mutateAsync({ filename: file.name, mimeType: file.type || "application/octet-stream", base64Data, size: file.size });
        setUploads(p => p.map(u => u.id === id ? { ...u, progress: 100, status: "done" } : u));
        setTimeout(() => setUploads(p => p.filter(u => u.id !== id)), 2000);
      } catch {
        setUploads(p => p.map(u => u.id === id ? { ...u, status: "error" } : u));
        setTimeout(() => setUploads(p => p.filter(u => u.id !== id)), 3000);
      }
    }
  }, [uploadMutation]);

  const allFiles = (files || []) as any[];
  const filtered = allFiles.filter(f => !search || (f.filename || "").toLowerCase().includes(search.toLowerCase()));
  const totalSize = allFiles.reduce((acc: number, f: any) => acc + (f.size || 0), 0);

  return (
    <div className="h-full flex flex-col relative"
      onDragOver={e => { e.preventDefault(); setDragging(true); }}
      onDragLeave={e => { if (!e.currentTarget.contains(e.relatedTarget as Node)) setDragging(false); }}
      onDrop={e => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files); }}
    >
      <AnimatePresence>
        {dragging && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-background/95 backdrop-blur border-2 border-dashed border-primary rounded-xl m-2"
          >
            <div className="text-center">
              <Upload className="h-12 w-12 text-primary mx-auto mb-3 animate-bounce" />
              <p className="text-lg font-semibold text-foreground">Drop files to upload</p>
              <p className="text-sm text-muted-foreground mt-1">Supports all file types up to 16MB</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="border-b border-border/50 px-6 py-4 flex items-center justify-between shrink-0 bg-background/80 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center"><FolderOpen className="h-4 w-4 text-primary" /></div>
          <div><h1 className="text-base font-semibold text-foreground">Files</h1><p className="text-xs text-muted-foreground">{allFiles.length} files · {formatBytes(totalSize)}</p></div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center border border-border/50 rounded-lg overflow-hidden">
            <button onClick={() => setView("grid")} className={"p-1.5 transition-colors " + (view === "grid" ? "bg-accent" : "hover:bg-accent/50")}><Grid className="h-3.5 w-3.5 text-muted-foreground" /></button>
            <button onClick={() => setView("list")} className={"p-1.5 transition-colors " + (view === "list" ? "bg-accent" : "hover:bg-accent/50")}><List className="h-3.5 w-3.5 text-muted-foreground" /></button>
          </div>
          <input ref={fileRef} type="file" multiple className="hidden" onChange={e => handleFiles(e.target.files)} />
          <Button onClick={() => fileRef.current?.click()} size="sm" className="gap-1.5"><Upload className="h-3.5 w-3.5" />Upload</Button>
        </div>
      </div>
      <AnimatePresence>
        {uploads.length > 0 && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="border-b border-border/50 px-6 py-3 space-y-2 bg-muted/20 shrink-0"
          >
            {uploads.map(u => (
              <div key={u.id} className="flex items-center gap-3">
                {u.status === "done" ? <CheckCircle2 className="h-4 w-4 text-green-400 shrink-0" /> : u.status === "error" ? <X className="h-4 w-4 text-destructive shrink-0" /> : <Loader2 className="h-4 w-4 text-primary animate-spin shrink-0" />}
                <span className="text-xs text-foreground flex-1 truncate">{u.name}</span>
                {u.status === "uploading" && <div className="w-24"><Progress value={u.progress} className="h-1" /></div>}
                {u.status === "done" && <span className="text-xs text-green-400 font-medium">Done</span>}
                {u.status === "error" && <span className="text-xs text-destructive font-medium">Failed</span>}
              </div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
      <div className="px-6 py-3 border-b border-border/50 shrink-0">
        <div className="relative max-w-sm">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search files..." className="w-full h-8 pl-8 pr-3 text-xs bg-muted/50 border border-border/50 rounded-lg focus:outline-none focus:ring-1 focus:ring-ring text-foreground placeholder:text-muted-foreground" />
        </div>
      </div>
      <ScrollArea className="flex-1 custom-scrollbar">
        <div className="p-6">
          {isLoading ? (
            <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-14 rounded-xl bg-muted/30 animate-pulse" />)}</div>
          ) : filtered.length === 0 ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center py-16 gap-4">
              <div className="h-14 w-14 rounded-2xl bg-muted/50 flex items-center justify-center border-2 border-dashed border-border/50"><Upload className="h-7 w-7 text-muted-foreground/40" /></div>
              <div className="text-center"><p className="text-sm font-medium text-foreground mb-1">No files yet</p><p className="text-xs text-muted-foreground">Drag and drop files here, or click Upload</p></div>
              <Button onClick={() => fileRef.current?.click()} size="sm" variant="outline" className="gap-2"><Plus className="h-3.5 w-3.5" />Upload files</Button>
            </motion.div>
          ) : view === "grid" ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {filtered.map((file: any, i: number) => {
                const Icon = getFileIcon(file.mimeType);
                return (
                  <motion.div key={file.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.03 }}
                    className="bg-card border border-border/50 rounded-xl p-4 hover:border-border transition-all group flex flex-col gap-3"
                  >
                    <div className="h-12 w-12 rounded-xl bg-muted/50 flex items-center justify-center mx-auto"><Icon className="h-6 w-6 text-muted-foreground" /></div>
                    <div className="text-center"><p className="text-xs font-medium text-foreground truncate">{file.filename}</p><p className="text-xs text-muted-foreground mt-0.5">{formatBytes(file.size || 0)}</p></div>
                    <div className="flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      {file.url && <a href={file.url} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors"><Download className="h-3.5 w-3.5" /></a>}
                      <button onClick={() => deleteFile.mutate({ id: file.id })} className="text-muted-foreground hover:text-destructive transition-colors"><Trash2 className="h-3.5 w-3.5" /></button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <div className="space-y-2">
              {filtered.map((file: any, i: number) => {
                const Icon = getFileIcon(file.mimeType);
                const ext = (file.mimeType || "").split("/")[1]?.toUpperCase() || "FILE";
                return (
                  <motion.div key={file.id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.02 }}
                    className="bg-card border border-border/50 rounded-xl px-4 py-3 hover:border-border transition-all group flex items-center gap-4"
                  >
                    <div className="h-9 w-9 rounded-lg bg-muted/50 flex items-center justify-center shrink-0"><Icon className="h-4 w-4 text-muted-foreground" /></div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{file.filename}</p>
                      <div className="flex items-center gap-3 mt-0.5">
                        <span className="text-xs text-muted-foreground">{formatBytes(file.size || 0)}</span>
                        <Badge variant="outline" className="text-xs">{ext}</Badge>
                        <span className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="h-2.5 w-2.5" />{new Date(file.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {file.url && <a href={file.url} target="_blank" rel="noopener noreferrer"><Button size="sm" variant="ghost" className="h-7 px-2"><Download className="h-3.5 w-3.5" /></Button></a>}
                      <Button size="sm" variant="ghost" className="h-7 px-2 text-muted-foreground hover:text-destructive" onClick={() => deleteFile.mutate({ id: file.id })}><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
