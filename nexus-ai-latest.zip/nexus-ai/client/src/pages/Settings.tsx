import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import {
  Settings as SettingsIcon, User, Palette, Brain, Bell, Shield,
  Save, Loader2, Check, Moon, Sun, Monitor, Zap, RefreshCw,
  ChevronRight, Info,
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";

const SECTIONS = [
  { id: "profile", label: "Profile", icon: User },
  { id: "appearance", label: "Appearance", icon: Palette },
  { id: "agent", label: "Agent Config", icon: Brain },
  { id: "notifications", label: "Notifications", icon: Bell },
  { id: "security", label: "Security", icon: Shield },
];

const MODEL_OPTIONS = [
  { value: "gpt-4o", label: "GPT-4o", badge: "Recommended", desc: "Most capable, best for complex tasks" },
  { value: "gpt-4o-mini", label: "GPT-4o Mini", badge: "Fast", desc: "Faster and more cost-efficient" },
  { value: "gpt-4-turbo", label: "GPT-4 Turbo", badge: "Powerful", desc: "High capability with large context" },
];

const THEME_OPTIONS = [
  { value: "dark", label: "Dark", icon: Moon },
  { value: "light", label: "Light", icon: Sun },
  { value: "system", label: "System", icon: Monitor },
];

function SettingRow({ label, description, children }: { label: string; description?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-6 py-4">
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-foreground">{label}</p>
        {description && <p className="text-xs text-muted-foreground mt-0.5">{description}</p>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`relative h-5 w-9 rounded-full transition-colors ${checked ? "bg-primary" : "bg-muted"}`}
    >
      <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform ${checked ? "translate-x-4" : "translate-x-0.5"}`} />
    </button>
  );
}

export default function Settings() {
  const { user } = useAuth();
  const [activeSection, setActiveSection] = useState("profile");
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  // Profile
  const [displayName, setDisplayName] = useState(user?.name || "");

  // Appearance
  const [theme, setTheme] = useState("dark");
  const [compactMode, setCompactMode] = useState(false);
  const [animationsEnabled, setAnimationsEnabled] = useState(true);

  // Agent Config
  const [selectedModel, setSelectedModel] = useState("gpt-4o");
  const [maxIterations, setMaxIterations] = useState(10);
  const [temperature, setTemperature] = useState(0.7);
  const [autoTitle, setAutoTitle] = useState(true);
  const [showThinking, setShowThinking] = useState(true);
  const [streamingEnabled, setStreamingEnabled] = useState(true);

  // Notifications
  const [taskComplete, setTaskComplete] = useState(true);
  const [taskFailed, setTaskFailed] = useState(true);
  const [newFeatures, setNewFeatures] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await new Promise(r => setTimeout(r, 800));
    setSaving(false);
    setSaved(true);
    toast.success("Settings saved successfully");
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="flex h-full bg-background">
      {/* Sidebar */}
      <div className="w-52 border-r border-border/50 flex flex-col shrink-0">
        <div className="p-4 border-b border-border/50">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-lg bg-primary/10 flex items-center justify-center">
              <SettingsIcon className="h-3.5 w-3.5 text-primary" />
            </div>
            <span className="text-sm font-semibold text-foreground">Settings</span>
          </div>
        </div>
        <nav className="p-2 space-y-0.5 flex-1">
          {SECTIONS.map(s => {
            const Icon = s.icon;
            return (
              <button
                key={s.id}
                onClick={() => setActiveSection(s.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors text-sm ${
                  activeSection === s.id
                    ? "bg-primary/10 text-primary font-medium"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                }`}
              >
                <Icon className="h-3.5 w-3.5 shrink-0" />
                {s.label}
                {activeSection === s.id && <ChevronRight className="h-3 w-3 ml-auto" />}
              </button>
            );
          })}
        </nav>
        <div className="p-3 border-t border-border/50">
          <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-muted/30">
            <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
              <User className="h-3 w-3 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-foreground truncate">{user?.name || "User"}</p>
              <p className="text-xs text-muted-foreground truncate">{user?.email || ""}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="border-b border-border/50 px-6 py-4 flex items-center justify-between shrink-0 bg-background/80 backdrop-blur">
          <div>
            <h1 className="text-base font-semibold text-foreground capitalize">{activeSection === "agent" ? "Agent Configuration" : activeSection}</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {activeSection === "profile" && "Manage your personal information"}
              {activeSection === "appearance" && "Customize the look and feel"}
              {activeSection === "agent" && "Configure AI agent behavior and models"}
              {activeSection === "notifications" && "Control notification preferences"}
              {activeSection === "security" && "Account security and privacy settings"}
            </p>
          </div>
          <Button onClick={handleSave} disabled={saving} size="sm" className="gap-2">
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : saved ? <Check className="h-3.5 w-3.5" /> : <Save className="h-3.5 w-3.5" />}
            {saving ? "Saving..." : saved ? "Saved!" : "Save Changes"}
          </Button>
        </div>

        <ScrollArea className="flex-1 custom-scrollbar">
          <div className="p-6 max-w-2xl">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
            >
              {/* Profile Section */}
              {activeSection === "profile" && (
                <div className="space-y-1">
                  <div className="flex items-center gap-4 p-4 bg-card border border-border/50 rounded-xl mb-6">
                    <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-primary/20 to-purple-500/20 border border-primary/20 flex items-center justify-center">
                      <User className="h-7 w-7 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">{user?.name || "User"}</p>
                      <p className="text-sm text-muted-foreground">{user?.email || "No email"}</p>
                      <Badge variant="outline" className="text-xs mt-1 capitalize">{user?.role || "user"}</Badge>
                    </div>
                  </div>
                  <div className="bg-card border border-border/50 rounded-xl px-4 divide-y divide-border/30">
                    <SettingRow label="Display Name" description="How your name appears across the platform">
                      <input
                        value={displayName}
                        onChange={e => setDisplayName(e.target.value)}
                        className="h-8 px-3 text-sm bg-muted/50 border border-border/50 rounded-lg focus:outline-none focus:ring-1 focus:ring-ring text-foreground w-48"
                      />
                    </SettingRow>
                    <SettingRow label="Email" description="Your account email address">
                      <span className="text-sm text-muted-foreground">{user?.email || "—"}</span>
                    </SettingRow>
                    <SettingRow label="Account Role" description="Your permission level on this platform">
                      <Badge variant="outline" className="capitalize">{user?.role || "user"}</Badge>
                    </SettingRow>
                    <SettingRow label="Login Method" description="How you authenticate">
                      <Badge variant="secondary" className="capitalize">{user?.loginMethod || "OAuth"}</Badge>
                    </SettingRow>
                  </div>
                </div>
              )}

              {/* Appearance Section */}
              {activeSection === "appearance" && (
                <div className="space-y-6">
                  <div className="bg-card border border-border/50 rounded-xl p-4">
                    <p className="text-sm font-medium text-foreground mb-3">Theme</p>
                    <div className="grid grid-cols-3 gap-3">
                      {THEME_OPTIONS.map(opt => {
                        const Icon = opt.icon;
                        return (
                          <button
                            key={opt.value}
                            onClick={() => setTheme(opt.value)}
                            className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${
                              theme === opt.value
                                ? "border-primary bg-primary/5 text-primary"
                                : "border-border/50 hover:border-border text-muted-foreground hover:text-foreground"
                            }`}
                          >
                            <Icon className="h-5 w-5" />
                            <span className="text-xs font-medium">{opt.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div className="bg-card border border-border/50 rounded-xl px-4 divide-y divide-border/30">
                    <SettingRow label="Compact Mode" description="Reduce spacing for a denser layout">
                      <Toggle checked={compactMode} onChange={setCompactMode} />
                    </SettingRow>
                    <SettingRow label="Animations" description="Enable motion and transition effects">
                      <Toggle checked={animationsEnabled} onChange={setAnimationsEnabled} />
                    </SettingRow>
                  </div>
                </div>
              )}

              {/* Agent Config Section */}
              {activeSection === "agent" && (
                <div className="space-y-6">
                  <div className="bg-card border border-border/50 rounded-xl p-4">
                    <p className="text-sm font-medium text-foreground mb-1">Language Model</p>
                    <p className="text-xs text-muted-foreground mb-3">Select the AI model powering the agent</p>
                    <div className="space-y-2">
                      {MODEL_OPTIONS.map(opt => (
                        <button
                          key={opt.value}
                          onClick={() => setSelectedModel(opt.value)}
                          className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${
                            selectedModel === opt.value
                              ? "border-primary bg-primary/5"
                              : "border-border/50 hover:border-border"
                          }`}
                        >
                          <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ${selectedModel === opt.value ? "bg-primary/10" : "bg-muted/50"}`}>
                            <Brain className={`h-4 w-4 ${selectedModel === opt.value ? "text-primary" : "text-muted-foreground"}`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium text-foreground">{opt.label}</span>
                              <Badge variant="outline" className="text-xs">{opt.badge}</Badge>
                            </div>
                            <p className="text-xs text-muted-foreground">{opt.desc}</p>
                          </div>
                          {selectedModel === opt.value && <Check className="h-4 w-4 text-primary shrink-0" />}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-card border border-border/50 rounded-xl px-4 divide-y divide-border/30">
                    <SettingRow label="Max Iterations" description="Maximum reasoning steps per task (1–20)">
                      <div className="flex items-center gap-2">
                        <input
                          type="range" min={1} max={20} value={maxIterations}
                          onChange={e => setMaxIterations(Number(e.target.value))}
                          className="w-24 accent-primary"
                        />
                        <span className="text-sm text-foreground w-6 text-right">{maxIterations}</span>
                      </div>
                    </SettingRow>
                    <SettingRow label="Temperature" description="Creativity vs. precision (0 = precise, 1 = creative)">
                      <div className="flex items-center gap-2">
                        <input
                          type="range" min={0} max={1} step={0.1} value={temperature}
                          onChange={e => setTemperature(Number(e.target.value))}
                          className="w-24 accent-primary"
                        />
                        <span className="text-sm text-foreground w-8 text-right">{temperature.toFixed(1)}</span>
                      </div>
                    </SettingRow>
                    <SettingRow label="Auto-generate Titles" description="Automatically name new conversations">
                      <Toggle checked={autoTitle} onChange={setAutoTitle} />
                    </SettingRow>
                    <SettingRow label="Show Thinking Steps" description="Display agent reasoning in chat">
                      <Toggle checked={showThinking} onChange={setShowThinking} />
                    </SettingRow>
                    <SettingRow label="Streaming Responses" description="Show responses as they are generated">
                      <Toggle checked={streamingEnabled} onChange={setStreamingEnabled} />
                    </SettingRow>
                  </div>

                  <div className="flex items-start gap-3 p-3 bg-blue-500/5 border border-blue-500/20 rounded-xl">
                    <Info className="h-4 w-4 text-blue-400 shrink-0 mt-0.5" />
                    <p className="text-xs text-muted-foreground">Agent configuration changes apply to new conversations. Existing conversations retain their original settings.</p>
                  </div>
                </div>
              )}

              {/* Notifications Section */}
              {activeSection === "notifications" && (
                <div className="bg-card border border-border/50 rounded-xl px-4 divide-y divide-border/30">
                  <SettingRow label="Task Completed" description="Notify when an autonomous task finishes">
                    <Toggle checked={taskComplete} onChange={setTaskComplete} />
                  </SettingRow>
                  <SettingRow label="Task Failed" description="Notify when a task encounters an error">
                    <Toggle checked={taskFailed} onChange={setTaskFailed} />
                  </SettingRow>
                  <SettingRow label="New Features" description="Updates about new platform capabilities">
                    <Toggle checked={newFeatures} onChange={setNewFeatures} />
                  </SettingRow>
                </div>
              )}

              {/* Security Section */}
              {activeSection === "security" && (
                <div className="space-y-4">
                  <div className="bg-card border border-border/50 rounded-xl px-4 divide-y divide-border/30">
                    <SettingRow label="Authentication Method" description="Your current sign-in method">
                      <Badge variant="secondary">Manus OAuth</Badge>
                    </SettingRow>
                    <SettingRow label="Session Management" description="Active sessions on this account">
                      <Button size="sm" variant="outline" className="h-7 text-xs gap-1.5">
                        <RefreshCw className="h-3 w-3" />View Sessions
                      </Button>
                    </SettingRow>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                    <Shield className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-medium text-foreground mb-0.5">Security Notice</p>
                      <p className="text-xs text-muted-foreground">Your account is protected by Manus OAuth. All sessions are encrypted and monitored for suspicious activity.</p>
                    </div>
                  </div>
                  <div className="p-4 bg-card border border-destructive/20 rounded-xl">
                    <p className="text-sm font-medium text-foreground mb-1">Danger Zone</p>
                    <p className="text-xs text-muted-foreground mb-3">These actions are irreversible. Please proceed with caution.</p>
                    <Button size="sm" variant="outline" className="border-destructive/50 text-destructive hover:bg-destructive/10 text-xs">
                      Delete All Conversations
                    </Button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
