import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import {
  Sparkles, MessageSquare, ListTodo, Wrench, Brain, FolderOpen,
  TrendingUp, Clock, CheckCircle2, Zap, ArrowRight, Activity,
  BarChart2, Globe, Code, FileText, ClipboardList,
} from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const toolIcons: Record<string, React.ElementType> = {
  web_search: Globe, execute_code: Code, read_file: FileText,
  write_file: FileText, analyze_data: BarChart2, create_plan: ClipboardList,
};

const QUICK_ACTIONS = [
  { icon: MessageSquare, label: "New Chat", desc: "Start a conversation", path: "/chat", color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20" },
  { icon: ListTodo, label: "Create Task", desc: "Run autonomous task", path: "/tasks", color: "text-green-400", bg: "bg-green-500/10 border-green-500/20" },
  { icon: Wrench, label: "Configure Tools", desc: "Manage agent tools", path: "/tools", color: "text-orange-400", bg: "bg-orange-500/10 border-orange-500/20" },
  { icon: FolderOpen, label: "Upload Files", desc: "Add documents", path: "/files", color: "text-purple-400", bg: "bg-purple-500/10 border-purple-500/20" },
];

const FEATURES = [
  { icon: Globe, title: "Web Search", desc: "Real-time information retrieval", color: "text-blue-400" },
  { icon: Code, title: "Code Execution", desc: "Write and run code autonomously", color: "text-green-400" },
  { icon: Brain, title: "Memory System", desc: "Persistent knowledge across sessions", color: "text-purple-400" },
  { icon: ClipboardList, title: "Task Planning", desc: "Break down complex goals", color: "text-cyan-400" },
  { icon: FileText, title: "File Analysis", desc: "Process documents and data", color: "text-yellow-400" },
  { icon: Activity, title: "Self-Reflection", desc: "Evaluate and improve responses", color: "text-pink-400" },
];

function StatCard({ label, value, icon: Icon, color, trend }: {
  label: string; value: string | number; icon: React.ElementType;
  color: string; trend?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border/50 rounded-xl p-5 hover:border-border transition-all group"
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${color.replace("text-", "bg-").replace("400", "500/10")} border ${color.replace("text-", "border-").replace("400", "500/20")}`}>
          <Icon className={`h-4.5 w-4.5 ${color}`} />
        </div>
        {trend && (
          <div className="flex items-center gap-1 text-xs text-green-400">
            <TrendingUp className="h-3 w-3" />
            {trend}
          </div>
        )}
      </div>
      <p className="text-2xl font-bold text-foreground">{value}</p>
      <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
    </motion.div>
  );
}

export default function Home() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: stats } = trpc.dashboard.stats.useQuery();
  const { data: recentActivity } = trpc.dashboard.recentActivity.useQuery();

  const s = stats as any;
  const activity = (recentActivity as any[]) || [];

  return (
    <div className="h-full overflow-y-auto custom-scrollbar">
      <div className="max-w-6xl mx-auto px-6 py-8 space-y-8">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-start justify-between"
        >
          <div>
            <div className="flex items-center gap-2 mb-1">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
              >
                <Sparkles className="h-5 w-5 text-primary" />
              </motion.div>
              <h1 className="text-2xl font-bold text-foreground">
                Good {new Date().getHours() < 12 ? "morning" : new Date().getHours() < 18 ? "afternoon" : "evening"},{" "}
                <span className="gradient-text">{user?.name?.split(" ")[0] || "there"}</span>
              </h1>
            </div>
            <p className="text-sm text-muted-foreground">
              Your autonomous AI agent is ready. What would you like to accomplish today?
            </p>
          </div>
          <Button onClick={() => setLocation("/chat")} className="gap-2 hidden sm:flex">
            <MessageSquare className="h-4 w-4" />
            Start Chatting
          </Button>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Total Conversations" value={s?.totalConversations ?? 0} icon={MessageSquare} color="text-blue-400" />
          <StatCard label="Tasks Completed" value={s?.completedTasks ?? 0} icon={CheckCircle2} color="text-green-400" trend="+12%" />
          <StatCard label="Tools Available" value={s?.activeTools ?? 6} icon={Wrench} color="text-orange-400" />
          <StatCard label="Memory Entries" value={s?.memoryEntries ?? 0} icon={Brain} color="text-purple-400" />
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
            <Zap className="h-4 w-4 text-primary" />
            Quick Actions
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {QUICK_ACTIONS.map((action, i) => (
              <motion.button
                key={action.path}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.07 }}
                onClick={() => setLocation(action.path)}
                className={`flex flex-col items-start gap-3 p-4 rounded-xl border ${action.bg} hover:scale-[1.02] transition-all text-left group`}
              >
                <div className={`h-8 w-8 rounded-lg flex items-center justify-center bg-background/50`}>
                  <action.icon className={`h-4 w-4 ${action.color}`} />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">{action.label}</p>
                  <p className="text-xs text-muted-foreground">{action.desc}</p>
                </div>
                <ArrowRight className={`h-3.5 w-3.5 ${action.color} opacity-0 group-hover:opacity-100 transition-opacity ml-auto`} />
              </motion.button>
            ))}
          </div>
        </div>

        {/* Main Content: Activity + Features */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Recent Activity */}
          <div className="lg:col-span-3">
            <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary" />
              Recent Activity
            </h2>
            <div className="bg-card border border-border/50 rounded-xl overflow-hidden">
              {activity.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 gap-3">
                  <div className="h-12 w-12 rounded-full bg-muted/50 flex items-center justify-center">
                    <Activity className="h-6 w-6 text-muted-foreground/50" />
                  </div>
                  <p className="text-sm text-muted-foreground">No activity yet</p>
                  <Button variant="outline" size="sm" onClick={() => setLocation("/chat")}>
                    Start your first chat
                  </Button>
                </div>
              ) : (
                <div className="divide-y divide-border/50">
                  {activity.slice(0, 8).map((item: any, i: number) => {
                    const Icon = item.type === "conversation" ? MessageSquare
                      : item.type === "task" ? ListTodo
                      : item.type === "file" ? FolderOpen
                      : toolIcons[item.toolName] || Zap;
                    return (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -8 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.04 }}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-accent/30 transition-colors cursor-pointer"
                        onClick={() => {
                          if (item.type === "conversation") setLocation("/chat");
                          else if (item.type === "task") setLocation("/tasks");
                        }}
                      >
                        <div className="h-7 w-7 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                          <Icon className="h-3.5 w-3.5 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm text-foreground truncate">{item.title}</p>
                          <p className="text-xs text-muted-foreground">{item.subtitle}</p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          {item.status && (
                            <Badge
                              variant={item.status === "completed" ? "default" : item.status === "failed" ? "destructive" : "secondary"}
                              className="text-xs h-5"
                            >
                              {item.status}
                            </Badge>
                          )}
                          <span className="text-xs text-muted-foreground whitespace-nowrap">
                            {item.timeAgo}
                          </span>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Capabilities */}
          <div className="lg:col-span-2">
            <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
              <Wrench className="h-4 w-4 text-primary" />
              Agent Capabilities
            </h2>
            <div className="space-y-2">
              {FEATURES.map((f, i) => (
                <motion.div
                  key={f.title}
                  initial={{ opacity: 0, x: 8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06 }}
                  className="flex items-center gap-3 p-3 rounded-lg bg-card border border-border/50 hover:border-border transition-all"
                >
                  <div className="h-7 w-7 rounded-md flex items-center justify-center bg-muted/50 shrink-0">
                    <f.icon className={`h-3.5 w-3.5 ${f.color}`} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-foreground">{f.title}</p>
                    <p className="text-xs text-muted-foreground truncate">{f.desc}</p>
                  </div>
                  <div className="h-1.5 w-1.5 rounded-full bg-green-400 shrink-0 ml-auto" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* CTA Banner */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-r from-primary/10 via-purple-500/5 to-transparent p-6"
        >
          <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-primary/5 blur-3xl pointer-events-none" />
          <div className="relative flex items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-bold text-foreground mb-1">Ready to build something amazing?</h3>
              <p className="text-sm text-muted-foreground">
                Nexus AI can autonomously research, code, analyze, and execute complex multi-step tasks.
              </p>
            </div>
            <Button onClick={() => setLocation("/chat")} className="shrink-0 gap-2 glow-primary-sm">
              <Sparkles className="h-4 w-4" />
              Let's go
            </Button>
          </div>
        </motion.div>

      </div>
    </div>
  );
}
