import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { motion, AnimatePresence } from "framer-motion";
import {
  Image, Video, Upload, Sparkles, Wand2, Download, Trash2,
  X, Play, ZoomIn, RefreshCw, ChevronDown, Loader2,
  ImagePlus, Film, Camera, Palette, Clock, CheckCircle2,
  AlertCircle, Eye, Copy, ExternalLink,
} from "lucide-react";
import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

// ─── Types ────────────────────────────────────────────────────────
type MediaItem = {
  id: number;
  type: "image" | "video";
  source: "generated" | "uploaded";
  prompt?: string | null;
  url: string;
  thumbnailUrl?: string | null;
  mimeType: string;
  size: number;
  filename?: string | null;
  style?: string | null;
  aspectRatio?: string | null;
  status: "pending" | "processing" | "completed" | "failed";
  createdAt: Date;
};

// ─── Constants ────────────────────────────────────────────────────
const IMAGE_STYLES = [
  { value: "photorealistic", label: "Photorealistic", icon: "📷" },
  { value: "artistic", label: "Artistic", icon: "🎨" },
  { value: "anime", label: "Anime", icon: "✨" },
  { value: "sketch", label: "Sketch", icon: "✏️" },
  { value: "cinematic", label: "Cinematic", icon: "🎬" },
  { value: "abstract", label: "Abstract", icon: "🌀" },
] as const;

const VIDEO_STYLES = [
  { value: "photorealistic", label: "Photorealistic", icon: "📷" },
  { value: "artistic", label: "Artistic", icon: "🎨" },
  { value: "anime", label: "Anime", icon: "✨" },
  { value: "cinematic", label: "Cinematic", icon: "🎬" },
  { value: "abstract", label: "Abstract", icon: "🌀" },
] as const;

const ASPECT_RATIOS = ["1:1", "16:9", "9:16", "4:3", "3:4"] as const;

const IMAGE_PROMPTS = [
  "A futuristic city at night with neon lights reflecting on wet streets",
  "A serene mountain lake at golden hour with perfect reflections",
  "An astronaut floating in space with Earth in the background",
  "A cozy coffee shop interior with warm lighting and books",
  "A dragon soaring over ancient castle ruins at sunset",
  "Abstract geometric patterns in vibrant electric blue and purple",
];

const VIDEO_PROMPTS = [
  "A timelapse of a city waking up at dawn",
  "Ocean waves crashing on a rocky shore in slow motion",
  "A forest path with light filtering through autumn leaves",
  "A rocket launching into a starry night sky",
  "Northern lights dancing over a snowy landscape",
];

// ─── Lightbox ─────────────────────────────────────────────────────
function Lightbox({ item, onClose }: { item: MediaItem; onClose: () => void }) {
  const utils = trpc.useUtils();
  const deleteMutation = trpc.media.delete.useMutation({
    onSuccess: () => {
      utils.media.list.invalidate();
      toast.success("Deleted successfully");
      onClose();
    },
  });

  const copyUrl = () => {
    navigator.clipboard.writeText(item.url);
    toast.success("URL copied to clipboard");
  };

  const download = () => {
    const a = document.createElement("a");
    a.href = item.url;
    a.download = item.filename || `nexus-${item.type}-${item.id}`;
    a.target = "_blank";
    a.click();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: "spring", damping: 25 }}
        className="relative max-w-5xl w-full max-h-[90vh] flex flex-col bg-card border border-border rounded-2xl overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border/50">
          <div className="flex items-center gap-3">
            <div className={`h-8 w-8 rounded-lg flex items-center justify-center ${
              item.type === "video" ? "bg-purple-500/15" : "bg-blue-500/15"
            }`}>
              {item.type === "video"
                ? <Film className="h-4 w-4 text-purple-400" />
                : <Image className="h-4 w-4 text-blue-400" />}
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">
                {item.filename || (item.source === "generated" ? "AI Generated" : "Uploaded")}
              </p>
              <p className="text-xs text-muted-foreground">
                {item.style && `${item.style} · `}
                {item.aspectRatio && `${item.aspectRatio} · `}
                {item.source === "generated" ? "AI Generated" : "User Upload"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={copyUrl} title="Copy URL">
              <Copy className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={download} title="Download">
              <Download className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost" size="icon"
              className="h-8 w-8 text-destructive hover:text-destructive"
              onClick={() => deleteMutation.mutate({ id: item.id })}
              disabled={deleteMutation.isPending}
              title="Delete"
            >
              {deleteMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Media */}
        <div className="flex-1 overflow-hidden flex items-center justify-center bg-black/40 min-h-0 p-4">
          {item.type === "video" && item.mimeType.startsWith("video/") ? (
            <video
              src={item.url}
              controls
              autoPlay
              className="max-h-full max-w-full rounded-lg object-contain"
            />
          ) : (
            <img
              src={item.url}
              alt={item.prompt || item.filename || "Media"}
              className="max-h-full max-w-full rounded-lg object-contain"
            />
          )}
        </div>

        {/* Prompt */}
        {item.prompt && (
          <div className="p-4 border-t border-border/50 bg-muted/20">
            <p className="text-xs text-muted-foreground mb-1 font-medium">Prompt</p>
            <p className="text-sm text-foreground/80 leading-relaxed">{item.prompt}</p>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}

// ─── Media Card ───────────────────────────────────────────────────
function MediaCard({ item, onClick }: { item: MediaItem; onClick: () => void }) {
  const [hovered, setHovered] = useState(false);
  const isVideo = item.type === "video";
  const thumb = item.thumbnailUrl || item.url;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -2 }}
      className="group relative aspect-square rounded-xl overflow-hidden bg-muted/30 border border-border/50 cursor-pointer"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={onClick}
    >
      <img
        src={thumb}
        alt={item.prompt || item.filename || "Media"}
        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        loading="lazy"
      />

      {/* Video overlay */}
      {isVideo && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="h-12 w-12 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center border border-white/20">
            <Play className="h-5 w-5 text-white ml-0.5" />
          </div>
        </div>
      )}

      {/* Hover overlay */}
      <AnimatePresence>
        {hovered && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/60 flex flex-col justify-between p-3"
          >
            <div className="flex items-center justify-between">
              <Badge
                variant="secondary"
                className={`text-xs ${item.source === "generated" ? "bg-primary/20 text-primary border-primary/30" : "bg-muted text-muted-foreground"}`}
              >
                {item.source === "generated" ? <><Sparkles className="h-2.5 w-2.5 mr-1" />AI</> : <><Upload className="h-2.5 w-2.5 mr-1" />Upload</>}
              </Badge>
              <div className={`h-6 w-6 rounded-md flex items-center justify-center ${isVideo ? "bg-purple-500/20" : "bg-blue-500/20"}`}>
                {isVideo ? <Film className="h-3 w-3 text-purple-400" /> : <Image className="h-3 w-3 text-blue-400" />}
              </div>
            </div>
            <div>
              {item.prompt && (
                <p className="text-xs text-white/80 line-clamp-2 leading-relaxed">{item.prompt}</p>
              )}
              {item.filename && !item.prompt && (
                <p className="text-xs text-white/80 truncate">{item.filename}</p>
              )}
              <div className="flex items-center gap-1.5 mt-2">
                <Eye className="h-3 w-3 text-white/60" />
                <span className="text-xs text-white/60">Click to view</span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ─── Generate Image Panel ─────────────────────────────────────────
function GenerateImagePanel({ onGenerated }: { onGenerated: () => void }) {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState<string>("photorealistic");
  const [aspectRatio, setAspectRatio] = useState<string>("1:1");
  const [editImageUrl, setEditImageUrl] = useState("");

  const generateMutation = trpc.media.generateImage.useMutation({
    onSuccess: () => {
      toast.success("Image generated successfully!");
      setPrompt("");
      onGenerated();
    },
    onError: (err) => toast.error(`Generation failed: ${err.message}`),
  });

  const handleGenerate = () => {
    if (!prompt.trim()) return toast.error("Please enter a prompt");
    generateMutation.mutate({
      prompt: prompt.trim(),
      style: style as any,
      aspectRatio: aspectRatio as any,
      originalImageUrl: editImageUrl || undefined,
    });
  };

  return (
    <div className="space-y-5">
      {/* Prompt */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Describe your image</label>
        <Textarea
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          placeholder="A futuristic city at night with neon lights reflecting on wet streets..."
          className="min-h-[100px] resize-none bg-muted/30 border-border/60 focus:border-primary/50 text-sm"
          onKeyDown={e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleGenerate(); }}
        />
        <p className="text-xs text-muted-foreground">Press Cmd+Enter to generate</p>
      </div>

      {/* Quick prompts */}
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground font-medium">Quick prompts</p>
        <div className="flex flex-wrap gap-2">
          {IMAGE_PROMPTS.map(p => (
            <button
              key={p}
              onClick={() => setPrompt(p)}
              className="text-xs px-2.5 py-1.5 rounded-lg bg-muted/50 hover:bg-muted border border-border/50 hover:border-border text-muted-foreground hover:text-foreground transition-all line-clamp-1 max-w-[200px] text-left"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Style */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Style</label>
        <div className="grid grid-cols-3 gap-2">
          {IMAGE_STYLES.map(s => (
            <button
              key={s.value}
              onClick={() => setStyle(s.value)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm transition-all ${
                style === s.value
                  ? "bg-primary/10 border-primary/40 text-primary"
                  : "bg-muted/30 border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
              }`}
            >
              <span>{s.icon}</span>
              <span className="text-xs font-medium">{s.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Aspect Ratio */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Aspect Ratio</label>
        <div className="flex gap-2 flex-wrap">
          {ASPECT_RATIOS.map(r => (
            <button
              key={r}
              onClick={() => setAspectRatio(r)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono transition-all ${
                aspectRatio === r
                  ? "bg-primary/10 border-primary/40 text-primary"
                  : "bg-muted/30 border-border/50 text-muted-foreground hover:border-border"
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Edit from image (optional) */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">
          Edit from existing image <span className="text-muted-foreground font-normal">(optional)</span>
        </label>
        <input
          type="url"
          value={editImageUrl}
          onChange={e => setEditImageUrl(e.target.value)}
          placeholder="https://... (paste image URL to edit it)"
          className="w-full px-3 py-2 rounded-lg bg-muted/30 border border-border/60 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 transition-colors"
        />
      </div>

      <Button
        onClick={handleGenerate}
        disabled={generateMutation.isPending || !prompt.trim()}
        className="w-full h-11 font-semibold glow-primary-sm"
        size="lg"
      >
        {generateMutation.isPending ? (
          <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Generating image...</>
        ) : (
          <><Wand2 className="h-4 w-4 mr-2" />Generate Image</>
        )}
      </Button>

      {generateMutation.isPending && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 p-4 rounded-xl bg-primary/5 border border-primary/20"
        >
          <div className="relative h-10 w-10 shrink-0">
            <div className="absolute inset-0 rounded-full bg-primary/20 animate-ping" />
            <div className="relative h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Sparkles className="h-5 w-5 text-primary animate-pulse" />
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">AI is painting your vision...</p>
            <p className="text-xs text-muted-foreground">This usually takes 10–20 seconds</p>
          </div>
        </motion.div>
      )}
    </div>
  );
}

// ─── Generate Video Panel ─────────────────────────────────────────
function GenerateVideoPanel({ onGenerated }: { onGenerated: () => void }) {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState<string>("cinematic");

  const generateMutation = trpc.media.generateVideo.useMutation({
    onSuccess: () => {
      toast.success("Video concept generated!");
      setPrompt("");
      onGenerated();
    },
    onError: (err) => toast.error(`Generation failed: ${err.message}`),
  });

  return (
    <div className="space-y-5">
      {/* Info banner */}
      <div className="flex items-start gap-3 p-4 rounded-xl bg-purple-500/5 border border-purple-500/20">
        <Film className="h-5 w-5 text-purple-400 shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-medium text-foreground">AI Video Concept Generation</p>
          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
            Describe your video concept and the AI will create a cinematic keyframe visualization — a high-quality still image representing the most impactful moment of your video.
          </p>
        </div>
      </div>

      {/* Prompt */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Describe your video concept</label>
        <Textarea
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          placeholder="A timelapse of a futuristic city waking up at dawn, with flying cars and holographic billboards..."
          className="min-h-[100px] resize-none bg-muted/30 border-border/60 focus:border-primary/50 text-sm"
          onKeyDown={e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) generateMutation.mutate({ prompt: prompt.trim(), style: style as any }); }}
        />
      </div>

      {/* Quick prompts */}
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground font-medium">Quick prompts</p>
        <div className="flex flex-wrap gap-2">
          {VIDEO_PROMPTS.map(p => (
            <button
              key={p}
              onClick={() => setPrompt(p)}
              className="text-xs px-2.5 py-1.5 rounded-lg bg-muted/50 hover:bg-muted border border-border/50 hover:border-border text-muted-foreground hover:text-foreground transition-all line-clamp-1 max-w-[220px] text-left"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Style */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">Visual Style</label>
        <div className="grid grid-cols-3 gap-2">
          {VIDEO_STYLES.map(s => (
            <button
              key={s.value}
              onClick={() => setStyle(s.value)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm transition-all ${
                style === s.value
                  ? "bg-purple-500/10 border-purple-500/40 text-purple-400"
                  : "bg-muted/30 border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
              }`}
            >
              <span>{s.icon}</span>
              <span className="text-xs font-medium">{s.label}</span>
            </button>
          ))}
        </div>
      </div>

      <Button
        onClick={() => {
          if (!prompt.trim()) return toast.error("Please enter a prompt");
          generateMutation.mutate({ prompt: prompt.trim(), style: style as any });
        }}
        disabled={generateMutation.isPending || !prompt.trim()}
        className="w-full h-11 font-semibold bg-purple-600 hover:bg-purple-700 text-white"
        size="lg"
      >
        {generateMutation.isPending ? (
          <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Generating concept...</>
        ) : (
          <><Film className="h-4 w-4 mr-2" />Generate Video Concept</>
        )}
      </Button>

      {generateMutation.isPending && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 p-4 rounded-xl bg-purple-500/5 border border-purple-500/20"
        >
          <div className="relative h-10 w-10 shrink-0">
            <div className="absolute inset-0 rounded-full bg-purple-500/20 animate-ping" />
            <div className="relative h-10 w-10 rounded-full bg-purple-500/10 flex items-center justify-center">
              <Film className="h-5 w-5 text-purple-400 animate-pulse" />
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">AI is crafting your video concept...</p>
            <p className="text-xs text-muted-foreground">Analyzing scene, generating keyframe...</p>
          </div>
        </motion.div>
      )}
    </div>
  );
}

// ─── Upload Panel ─────────────────────────────────────────────────
function UploadPanel({ onUploaded }: { onUploaded: () => void }) {
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [previews, setPreviews] = useState<{ name: string; url: string; type: string }[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();

  const uploadMutation = trpc.media.upload.useMutation({
    onSuccess: () => {
      utils.media.list.invalidate();
      onUploaded();
    },
    onError: (err) => toast.error(`Upload failed: ${err.message}`),
  });

  const processFiles = useCallback(async (fileList: FileList) => {
    const files = Array.from(fileList).filter(f =>
      f.type.startsWith("image/") || f.type.startsWith("video/")
    );
    if (!files.length) return toast.error("Only image and video files are supported");

    // Show previews
    const newPreviews = await Promise.all(files.map(f => new Promise<{ name: string; url: string; type: string }>(resolve => {
      const reader = new FileReader();
      reader.onload = e => resolve({ name: f.name, url: e.target?.result as string, type: f.type });
      reader.readAsDataURL(f);
    })));
    setPreviews(prev => [...prev, ...newPreviews]);

    setUploading(true);
    let successCount = 0;
    for (const file of files) {
      try {
        const base64Data = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = e => {
            const result = e.target?.result as string;
            resolve(result.split(",")[1]); // strip data URL prefix
          };
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
        await uploadMutation.mutateAsync({
          filename: file.name,
          mimeType: file.type,
          size: file.size,
          base64Data,
        });
        successCount++;
      } catch {
        toast.error(`Failed to upload ${file.name}`);
      }
    }
    setUploading(false);
    if (successCount > 0) toast.success(`${successCount} file${successCount > 1 ? "s" : ""} uploaded!`);
  }, [uploadMutation]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    if (e.dataTransfer.files.length) processFiles(e.dataTransfer.files);
  }, [processFiles]);

  return (
    <div className="space-y-5">
      {/* Drop zone */}
      <motion.div
        animate={{ borderColor: dragging ? "hsl(var(--primary))" : "hsl(var(--border))" }}
        className={`relative border-2 border-dashed rounded-2xl p-10 text-center transition-colors cursor-pointer ${
          dragging ? "bg-primary/5" : "bg-muted/20 hover:bg-muted/30"
        }`}
        onDragOver={e => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          multiple
          accept="image/*,video/*"
          onChange={e => e.target.files && processFiles(e.target.files)}
        />
        <motion.div
          animate={{ scale: dragging ? 1.1 : 1 }}
          className="flex flex-col items-center gap-4"
        >
          <div className={`h-16 w-16 rounded-2xl flex items-center justify-center transition-colors ${
            dragging ? "bg-primary/20" : "bg-muted/50"
          }`}>
            {uploading
              ? <Loader2 className="h-8 w-8 text-primary animate-spin" />
              : <Upload className={`h-8 w-8 ${dragging ? "text-primary" : "text-muted-foreground"}`} />
            }
          </div>
          <div>
            <p className="text-base font-semibold text-foreground">
              {uploading ? "Uploading..." : dragging ? "Drop to upload" : "Drop files here"}
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              or <span className="text-primary">click to browse</span>
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Supports: JPG, PNG, GIF, WebP, MP4, MOV, WebM
            </p>
          </div>
        </motion.div>
      </motion.div>

      {/* Previews */}
      {previews.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-foreground">Selected files</p>
            <button
              onClick={() => setPreviews([])}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              Clear all
            </button>
          </div>
          <div className="grid grid-cols-4 gap-3">
            {previews.map((p, i) => (
              <div key={i} className="relative aspect-square rounded-lg overflow-hidden bg-muted/30 border border-border/50">
                {p.type.startsWith("video/") ? (
                  <div className="w-full h-full flex items-center justify-center">
                    <Film className="h-8 w-8 text-muted-foreground" />
                  </div>
                ) : (
                  <img src={p.url} alt={p.name} className="w-full h-full object-cover" />
                )}
                <div className="absolute bottom-0 left-0 right-0 bg-black/60 px-1.5 py-1">
                  <p className="text-xs text-white truncate">{p.name}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tips */}
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground font-medium">Tips</p>
        <div className="grid grid-cols-2 gap-2">
          {[
            { icon: Camera, text: "High-res images work best" },
            { icon: Film, text: "Videos up to 100MB supported" },
            { icon: ImagePlus, text: "Use uploaded images as edit base" },
            { icon: Palette, text: "All major formats supported" },
          ].map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center gap-2 p-2.5 rounded-lg bg-muted/20 border border-border/30">
              <Icon className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
              <p className="text-xs text-muted-foreground">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Gallery ──────────────────────────────────────────────────────
function Gallery({ items, isLoading, onRefresh }: {
  items: MediaItem[];
  isLoading: boolean;
  onRefresh: () => void;
}) {
  const [lightboxItem, setLightboxItem] = useState<MediaItem | null>(null);
  const [filter, setFilter] = useState<"all" | "image" | "video" | "generated" | "uploaded">("all");

  const filtered = items.filter(item => {
    if (filter === "all") return true;
    if (filter === "image") return item.type === "image";
    if (filter === "video") return item.type === "video";
    if (filter === "generated") return item.source === "generated";
    if (filter === "uploaded") return item.source === "uploaded";
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Filter bar */}
      <div className="flex items-center justify-between">
        <div className="flex gap-1.5 flex-wrap">
          {(["all", "image", "video", "generated", "uploaded"] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all capitalize ${
                filter === f
                  ? "bg-primary/10 text-primary border border-primary/30"
                  : "bg-muted/30 text-muted-foreground hover:text-foreground border border-transparent"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">{filtered.length} items</span>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onRefresh}>
            <RefreshCw className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      {/* Grid */}
      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="aspect-square rounded-xl bg-muted/30 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 gap-4">
          <div className="h-16 w-16 rounded-2xl bg-muted/30 flex items-center justify-center">
            <ImagePlus className="h-8 w-8 text-muted-foreground" />
          </div>
          <div className="text-center">
            <p className="text-sm font-medium text-foreground">No media yet</p>
            <p className="text-xs text-muted-foreground mt-1">
              Generate images or videos with AI, or upload your own
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          <AnimatePresence>
            {filtered.map(item => (
              <MediaCard key={item.id} item={item} onClick={() => setLightboxItem(item)} />
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxItem && (
          <Lightbox item={lightboxItem} onClose={() => setLightboxItem(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────
export default function MediaStudio() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("gallery");
  const [generateTab, setGenerateTab] = useState("image");

  const { data: allMedia = [], isLoading, refetch } = trpc.media.list.useQuery({ type: undefined });
  const items = allMedia as MediaItem[];

  const imageCount = items.filter(i => i.type === "image").length;
  const videoCount = items.filter(i => i.type === "video").length;
  const generatedCount = items.filter(i => i.source === "generated").length;

  const handleCreated = () => {
    refetch();
    setActiveTab("gallery");
  };

  return (
    <div className="h-full overflow-y-auto custom-scrollbar">
      <div className="max-w-7xl mx-auto px-6 py-8 space-y-6">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-start justify-between"
        >
          <div>
            <div className="flex items-center gap-3 mb-1">
              <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-pink-500/20 to-purple-500/20 border border-pink-500/20 flex items-center justify-center">
                <Palette className="h-5 w-5 text-pink-400" />
              </div>
              <h1 className="text-2xl font-bold text-foreground">Media Studio</h1>
            </div>
            <p className="text-sm text-muted-foreground">
              Generate AI images & videos, or upload your own media
            </p>
          </div>
          <Button
            onClick={() => setActiveTab("generate")}
            className="gap-2 glow-primary-sm"
          >
            <Wand2 className="h-4 w-4" />
            Create New
          </Button>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-4"
        >
          {[
            { label: "Total Media", value: items.length, icon: ImagePlus, color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20" },
            { label: "Images", value: imageCount, icon: Image, color: "text-green-400", bg: "bg-green-500/10 border-green-500/20" },
            { label: "Videos", value: videoCount, icon: Film, color: "text-purple-400", bg: "bg-purple-500/10 border-purple-500/20" },
          ].map(({ label, value, icon: Icon, color, bg }) => (
            <div key={label} className="bg-card border border-border/50 rounded-xl p-4 flex items-center gap-4">
              <div className={`h-10 w-10 rounded-xl flex items-center justify-center border ${bg}`}>
                <Icon className={`h-5 w-5 ${color}`} />
              </div>
              <div>
                <p className="text-xl font-bold text-foreground">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </div>
          ))}
        </motion.div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-muted/30 border border-border/50 h-10">
            <TabsTrigger value="gallery" className="gap-2 text-sm">
              <Eye className="h-3.5 w-3.5" />
              Gallery
              {items.length > 0 && (
                <Badge variant="secondary" className="h-4 px-1.5 text-xs ml-1">{items.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="generate" className="gap-2 text-sm">
              <Wand2 className="h-3.5 w-3.5" />
              AI Generate
            </TabsTrigger>
            <TabsTrigger value="upload" className="gap-2 text-sm">
              <Upload className="h-3.5 w-3.5" />
              Upload
            </TabsTrigger>
          </TabsList>

          {/* Gallery Tab */}
          <TabsContent value="gallery" className="mt-6">
            <Gallery items={items} isLoading={isLoading} onRefresh={refetch} />
          </TabsContent>

          {/* Generate Tab */}
          <TabsContent value="generate" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left: Generation form */}
              <div className="bg-card border border-border/50 rounded-2xl p-6">
                <Tabs value={generateTab} onValueChange={setGenerateTab}>
                  <TabsList className="bg-muted/30 border border-border/50 w-full mb-6">
                    <TabsTrigger value="image" className="flex-1 gap-2">
                      <Image className="h-3.5 w-3.5" />
                      Image
                    </TabsTrigger>
                    <TabsTrigger value="video" className="flex-1 gap-2">
                      <Film className="h-3.5 w-3.5" />
                      Video
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="image">
                    <GenerateImagePanel onGenerated={handleCreated} />
                  </TabsContent>
                  <TabsContent value="video">
                    <GenerateVideoPanel onGenerated={handleCreated} />
                  </TabsContent>
                </Tabs>
              </div>

              {/* Right: Recent generations */}
              <div className="bg-card border border-border/50 rounded-2xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    Recent Generations
                  </h3>
                  <Badge variant="secondary" className="text-xs">
                    {generatedCount} total
                  </Badge>
                </div>
                {isLoading ? (
                  <div className="grid grid-cols-2 gap-3">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <div key={i} className="aspect-square rounded-xl bg-muted/30 animate-pulse" />
                    ))}
                  </div>
                ) : items.filter(i => i.source === "generated").length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 gap-3">
                    <Sparkles className="h-10 w-10 text-muted-foreground/30" />
                    <p className="text-sm text-muted-foreground text-center">
                      Your AI-generated media will appear here
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    {items.filter(i => i.source === "generated").slice(0, 6).map(item => (
                      <MediaCard
                        key={item.id}
                        item={item}
                        onClick={() => { setActiveTab("gallery"); }}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Upload Tab */}
          <TabsContent value="upload" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-card border border-border/50 rounded-2xl p-6">
                <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Upload className="h-4 w-4 text-muted-foreground" />
                  Upload Media
                </h3>
                <UploadPanel onUploaded={handleCreated} />
              </div>

              {/* Right: Uploaded media */}
              <div className="bg-card border border-border/50 rounded-2xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    Recently Uploaded
                  </h3>
                  <Badge variant="secondary" className="text-xs">
                    {items.filter(i => i.source === "uploaded").length} total
                  </Badge>
                </div>
                {items.filter(i => i.source === "uploaded").length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 gap-3">
                    <Upload className="h-10 w-10 text-muted-foreground/30" />
                    <p className="text-sm text-muted-foreground text-center">
                      Your uploaded media will appear here
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    {items.filter(i => i.source === "uploaded").slice(0, 6).map(item => (
                      <MediaCard
                        key={item.id}
                        item={item}
                        onClick={() => setActiveTab("gallery")}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
