import { trpc } from "@/lib/trpc";
import { motion } from "framer-motion";
import {
  Wrench, Globe, Code, FileText, BarChart2, ClipboardList,
  Plus, ToggleLeft, ToggleRight, Zap, Sparkles, Info, Loader2, Search, Trash2,
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const BUILT_IN_TOOLS = [
  { name: "web_search", displayName: "Web Search", category: "search", description: "Search the internet for real-time information, news, and research.", icon: Globe, color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20", capabilities: ["Real-time web search", "News retrieval", "Fact checking"] },
  { name: "execute_code", displayName: "Code Executor", category: "code", description: "Write and execute code in a sandboxed environment with full output capture.", icon: Code, color: "text-green-400", bg: "bg-green-500/10 border-green-500/20", capabilities: ["Python execution", "Data processing", "Algorithm testing"] },
  { name: "read_file", displayName: "File Reader", category: "file", description: "Read and analyze files from the workspace including documents and data files.", icon: FileText, color: "text-yellow-400", bg: "bg-yellow-500/10 border-yellow-500/20", capabilities: ["Text file reading", "Code analysis", "Content extraction"] },
  { name: "write_file", displayName: "File Writer", category: "file", description: "Create and write files to the workspace in any text format.", icon: FileText, color: "text-orange-400", bg: "bg-orange-500/10 border-orange-500/20", capabilities: ["File creation", "Code generation", "Report saving"] },
  { name: "analyze_data", displayName: "Data Analyzer", category: "data", description: "Perform statistical analysis and generate insights from structured data.", icon: BarChart2, color: "text-purple-400", bg: "bg-purple-500/10 border-purple-500/20", capabilities: ["Statistical analysis", "Pattern detection", "Trend analysis"] },
  { name: "create_plan", displayName: "Task Planner", category: "data", description: "Break down complex goals into structured, executable subtasks.", icon: ClipboardList, color: "text-cyan-400", bg: "bg-cyan-500/10 border-cyan-500/20", capabilities: ["Goal decomposition", "Priority setting", "Progress tracking"] },
];

const categoryColors: Record<string, string> = {
  search: "text-blue-400 bg-blue-500/10", code: "text-green-400 bg-green-500/10",
  file: "text-yellow-400 bg-yellow-500/10", data: "text-purple-400 bg-purple-500/10",
  custom: "text-pink-400 bg-pink-500/10",
};

export default function Tools() {
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState("");
  const [newTool, setNewTool] = useState({ name: "", displayName: "", description: "", category: "custom" as const });

  const { data: customTools, refetch } = trpc.toolConfigs.list.useQuery();
  const createTool = trpc.toolConfigs.create.useMutation({
    onSuccess: () => { refetch(); setShowAdd(false); setNewTool({ name: "", displayName: "", description: "", category: "custom" }); toast.success("Tool added!"); },
    onError: e => toast.error(e.message),
  });
  const updateTool = trpc.toolConfigs.update.useMutation({ onSuccess: () => refetch() });
  const deleteTool = trpc.toolConfigs.delete.useMutation({ onSuccess: () => { refetch(); toast.success("Tool removed"); } });

  const allCustom = (customTools || []) as any[];
  const filteredBuiltIn = BUILT_IN_TOOLS.filter(t => !search || t.displayName.toLowerCase().includes(search.toLowerCase()));
  const filteredCustom = allCustom.filter(t => !search || t.displayName.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="h-full flex flex-col">
      <div className="border-b border-border/50 px-6 py-4 flex items-center justify-between shrink-0 bg-background/80 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center"><Wrench className="h-4 w-4 text-primary" /></div>
          <div><h1 className="text-base font-semibold text-foreground">Tools</h1><p className="text-xs text-muted-foreground">{BUILT_IN_TOOLS.length} built-in · {allCustom.length} custom</p></div>
        </div>
        <Button onClick={() => setShowAdd(true)} size="sm" className="gap-1.5"><Plus className="h-3.5 w-3.5" />Add Tool</Button>
      </div>
      <div className="px-6 py-3 border-b border-border/50 shrink-0">
        <div className="relative max-w-sm">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search tools..." className="w-full h-8 pl-8 pr-3 text-xs bg-muted/50 border border-border/50 rounded-lg focus:outline-none focus:ring-1 focus:ring-ring text-foreground placeholder:text-muted-foreground" />
        </div>
      </div>
      <ScrollArea className="flex-1 custom-scrollbar">
        <div className="p-6 space-y-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="h-4 w-4 text-primary" />
              <h2 className="text-sm font-semibold text-foreground">Built-in Tools</h2>
              <Tooltip><TooltipTrigger><Info className="h-3.5 w-3.5 text-muted-foreground" /></TooltipTrigger><TooltipContent>Always available to the agent</TooltipContent></Tooltip>
              <Badge variant="secondary" className="text-xs ml-auto">{filteredBuiltIn.length} tools</Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredBuiltIn.map((tool, i) => {
                const Icon = tool.icon;
                return (
                  <motion.div key={tool.name} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                    className={`bg-card border rounded-xl p-5 hover:border-border transition-all ${tool.bg}`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={`h-10 w-10 rounded-xl flex items-center justify-center bg-background/60 border ${tool.bg}`}><Icon className={`h-5 w-5 ${tool.color}`} /></div>
                        <div><h3 className="text-sm font-semibold text-foreground">{tool.displayName}</h3><Badge variant="outline" className={`text-xs mt-0.5 border-current/20`}>{tool.category}</Badge></div>
                      </div>
                      <div className="flex items-center gap-1.5"><div className="h-2 w-2 rounded-full bg-green-400 animate-pulse" /><span className="text-xs text-green-400 font-medium">Active</span></div>
                    </div>
                    <p className="text-xs text-muted-foreground mb-3 leading-relaxed">{tool.description}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {tool.capabilities.map(cap => <span key={cap} className="text-xs px-2 py-0.5 rounded-full bg-background/50 border border-border/50 text-muted-foreground">{cap}</span>)}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Wrench className="h-4 w-4 text-primary" /><h2 className="text-sm font-semibold text-foreground">Custom Tools</h2>
              <Badge variant="secondary" className="text-xs ml-auto">{filteredCustom.length} tools</Badge>
            </div>
            {filteredCustom.length === 0 ? (
              <div className="border border-dashed border-border/50 rounded-xl p-8 text-center">
                <Zap className="h-8 w-8 text-muted-foreground/30 mx-auto mb-3" />
                <p className="text-sm font-medium text-foreground mb-1">No custom tools yet</p>
                <p className="text-xs text-muted-foreground mb-4">Add custom tools to extend the agent's capabilities</p>
                <Button onClick={() => setShowAdd(true)} size="sm" variant="outline" className="gap-2"><Plus className="h-3.5 w-3.5" />Add Custom Tool</Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {filteredCustom.map((tool: any) => (
                  <motion.div key={tool.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                    className="bg-card border border-border/50 rounded-xl p-5 hover:border-border transition-all"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-xl flex items-center justify-center bg-muted/50 border border-border/50"><Zap className="h-5 w-5 text-primary" /></div>
                        <div><h3 className="text-sm font-semibold text-foreground">{tool.displayName}</h3><Badge variant="outline" className="text-xs mt-0.5">{tool.category}</Badge></div>
                      </div>
                      <button onClick={() => updateTool.mutate({ id: tool.id, enabled: !tool.enabled })}>
                        {tool.enabled ? <ToggleRight className="h-6 w-6 text-primary" /> : <ToggleLeft className="h-6 w-6 text-muted-foreground" />}
                      </button>
                    </div>
                    {tool.description && <p className="text-xs text-muted-foreground mb-3">{tool.description}</p>}
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-medium ${tool.enabled ? "text-green-400" : "text-muted-foreground"}`}>{tool.enabled ? "Enabled" : "Disabled"}</span>
                      <button onClick={() => deleteTool.mutate({ id: tool.id })} className="text-xs text-muted-foreground hover:text-destructive transition-colors flex items-center gap-1"><Trash2 className="h-3 w-3" />Remove</button>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </ScrollArea>
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Plus className="h-4 w-4 text-primary" />Add Custom Tool</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div><label className="text-xs font-medium text-muted-foreground mb-1.5 block">Tool ID *</label><Input value={newTool.name} onChange={e => setNewTool(p => ({ ...p, name: e.target.value.toLowerCase().replace(/\s+/g, "_") }))} placeholder="my_tool" className="h-9 text-sm font-mono" /></div>
              <div><label className="text-xs font-medium text-muted-foreground mb-1.5 block">Display Name *</label><Input value={newTool.displayName} onChange={e => setNewTool(p => ({ ...p, displayName: e.target.value }))} placeholder="My Tool" className="h-9 text-sm" /></div>
            </div>
            <div><label className="text-xs font-medium text-muted-foreground mb-1.5 block">Description</label><Textarea value={newTool.description} onChange={e => setNewTool(p => ({ ...p, description: e.target.value }))} placeholder="What does this tool do?" className="text-sm min-h-[60px] resize-none" /></div>
            <div><label className="text-xs font-medium text-muted-foreground mb-1.5 block">Category</label>
              <Select value={newTool.category} onValueChange={v => setNewTool(p => ({ ...p, category: v as any }))}>
                <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="search">Search</SelectItem><SelectItem value="code">Code</SelectItem><SelectItem value="file">File</SelectItem><SelectItem value="data">Data</SelectItem><SelectItem value="custom">Custom</SelectItem></SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button onClick={() => createTool.mutate(newTool)} disabled={!newTool.name || !newTool.displayName || createTool.isPending} className="gap-2">
              {createTool.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}Add Tool
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
