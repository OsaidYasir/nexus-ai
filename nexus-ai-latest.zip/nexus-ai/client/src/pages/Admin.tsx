import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Shield,
  Users,
  MessageSquare,
  ListTodo,
  FolderOpen,
  Activity,
} from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { motion } from "framer-motion";

export default function Admin() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (user && user.role !== "admin") {
      setLocation("/");
    }
  }, [user, setLocation]);

  const { data: stats, isLoading } = trpc.admin.stats.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  if (user?.role !== "admin") {
    return null;
  }

  const statCards = [
    { label: "Total Users", value: stats?.users ?? 0, icon: Users, color: "text-blue-400", bg: "bg-blue-400/10" },
    { label: "Conversations", value: stats?.conversations ?? 0, icon: MessageSquare, color: "text-emerald-400", bg: "bg-emerald-400/10" },
    { label: "Tasks", value: stats?.tasks ?? 0, icon: ListTodo, color: "text-purple-400", bg: "bg-purple-400/10" },
    { label: "Files", value: stats?.files ?? 0, icon: FolderOpen, color: "text-amber-400", bg: "bg-amber-400/10" },
  ];

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full custom-scrollbar">
      <div>
        <h1 className="text-2xl font-semibold text-foreground flex items-center gap-2">
          <Shield className="h-6 w-6 text-primary" />
          Admin Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          Platform overview and management.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className={`h-10 w-10 rounded-lg ${stat.bg} flex items-center justify-center`}>
                    <stat.icon className={`h-5 w-5 ${stat.color}`} />
                  </div>
                  <div>
                    {isLoading ? (
                      <Skeleton className="h-7 w-12" />
                    ) : (
                      <p className="text-2xl font-semibold text-foreground">{stat.value}</p>
                    )}
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* System Info */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Activity className="h-4 w-4 text-primary" />
            System Information
          </CardTitle>
          <CardDescription>Platform configuration and status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: "Platform", value: "Nexus AI Agent" },
              { label: "Version", value: "1.0.0" },
              { label: "Agent Engine", value: "LLM + Tool Loop" },
              { label: "Max Iterations", value: "5 per request" },
              { label: "Built-in Tools", value: "6 tools" },
              { label: "Database", value: "MySQL / TiDB" },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                <span className="text-sm text-muted-foreground">{item.label}</span>
                <span className="text-sm font-medium text-foreground">{item.value}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
