import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { motion, AnimatePresence } from "framer-motion";
import {
  MessageSquare, Plus, Send, Sparkles, Trash2, ChevronDown,
  ChevronRight, Copy, Check, Globe, Code, FileText, BarChart2,
  ClipboardList, Loader2, User, Clock, Search, X, PenLine,
  ImagePlus, Film, Paperclip,
} from "lucide-react";
import { useRef as useFileRef } from "react";
import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

type AgentStep = {
  type: string;
  title: string;
  content: string;
  toolName?: string;
  toolInput?: Record<string, unknown>;
  toolOutput?: string;
  status: string;
  durationMs?: number;
  timestamp: number;
};

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  steps?: AgentStep[];
  durationMs?: number;
  toolsUsed?: string[];
  isStreaming?: boolean;
  timestamp: number;
  attachments?: { type: "image" | "video"; url: string; name: string }[];
};

type Conversation = { id: number; title: string; updatedAt: Date };

const toolIcons: Record<string, React.ElementType> = {
  web_search: Globe, execute_code: Code, read_file: FileText,
  write_file: FileText, analyze_data: BarChart2, create_plan: ClipboardList,
};
const toolColors: Record<string, string> = {
  web_search: "text-blue-400", execute_code: "text-green-400",
  read_file: "text-yellow-400", write_file: "text-orange-400",
  analyze_data: "text-purple-400", create_plan: "text-cyan-400",
};

const SUGGESTIONS = [
  "Analyze the latest trends in AI and write a comprehensive report",
  "Write a Python script to process CSV data and generate visualizations",
  "Create a detailed project plan for building a mobile app",
  "Search for and summarize the best practices in system design",
  "Help me debug and optimize this algorithm for performance",
  "Research and compare the top cloud providers for a startup",
];

function StepCard({ step, index }: { step: AgentStep; index: number }) {
  const [expanded, setExpanded] = useState(false);
  const Icon = toolIcons[step.toolName || ""] || Sparkles;
  const colorClass = toolColors[step.toolName || ""] || "text-primary";
  const bgMap: Record<string, string> = {
    thinking: "bg-primary/5 border-primary/20",
    tool_call: "bg-green-500/5 border-green-500/20",
    tool_result: "bg-green-500/5 border-green-500/20",
    reflection: "bg-orange-500/5 border-orange-500/20",
    answer: "bg-purple-500/5 border-purple-500/20",
  };
  const dotMap: Record<string, string> = {
    thinking: "bg-primary", tool_call: "bg-green-400",
    tool_result: "bg-green-400", reflection: "bg-orange-400", answer: "bg-purple-400",
  };
  const bg = bgMap[step.type] || "bg-muted/30 border-border/50";
  const dot = dotMap[step.type] || "bg-muted-foreground";
  const hasDetail = !!(step.toolInput || step.toolOutput || step.content.length > 80);

  return (
    <motion.div
      initial={{ opacity: 0, x: -8 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.06, duration: 0.2 }}
      className={`rounded-lg border ${bg} overflow-hidden`}
    >
      <button
        onClick={() => hasDetail && setExpanded(!expanded)}
        className={`flex items-center gap-2.5 w-full px-3 py-2 text-left ${hasDetail ? "cursor-pointer" : "cursor-default"}`}
      >
        <div className={`h-1.5 w-1.5 rounded-full shrink-0 ${dot} ${step.status === "running" ? "animate-pulse" : ""}`} />
        <Icon className={`h-3.5 w-3.5 shrink-0 ${colorClass}`} />
        <span className="text-xs font-medium text-foreground flex-1 truncate">{step.title}</span>
        {step.durationMs && <span className="text-xs text-muted-foreground shrink-0">{step.durationMs}ms</span>}
        {hasDetail && <ChevronRight className={`h-3 w-3 text-muted-foreground shrink-0 transition-transform ${expanded ? "rotate-90" : ""}`} />}
      </button>
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-3 pb-3 space-y-2 border-t border-border/30 pt-2">
              {step.toolInput && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1 font-medium">Input</p>
                  <pre className="text-xs bg-background/50 rounded p-2 overflow-x-auto text-foreground/80 max-h-32 custom-scrollbar">
                    {JSON.stringify(step.toolInput, null, 2)}
                  </pre>
                </div>
              )}
              {step.toolOutput && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1 font-medium">Output</p>
                  <pre className="text-xs bg-background/50 rounded p-2 overflow-x-auto text-foreground/80 max-h-40 custom-scrollbar">
                    {(() => { try { return JSON.stringify(JSON.parse(step.toolOutput), null, 2); } catch { return step.toolOutput; } })()}
                  </pre>
                </div>
              )}
              {!step.toolInput && !step.toolOutput && step.content && (
                <p className="text-xs text-muted-foreground">{step.content}</p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function MessageBubble({ msg }: { msg: Message }) {
  const [copied, setCopied] = useState(false);
  const [stepsExpanded, setStepsExpanded] = useState(false);
  const isUser = msg.role === "user";

  const handleCopy = () => {
    navigator.clipboard.writeText(msg.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className={`flex gap-3 group ${isUser ? "flex-row-reverse" : "flex-row"}`}
    >
      <div className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 mt-1 ${
        isUser
          ? "bg-primary/15 border border-primary/30"
          : "bg-gradient-to-br from-primary/20 to-purple-500/20 border border-primary/20"
      }`}>
        {isUser ? <User className="h-4 w-4 text-primary" /> : <Sparkles className="h-4 w-4 text-primary" />}
      </div>

      <div className={`flex flex-col gap-2 max-w-[80%] min-w-0 ${isUser ? "items-end" : "items-start"}`}>
        <div className={`rounded-2xl px-4 py-3 ${
          isUser
            ? "bg-primary text-primary-foreground rounded-tr-sm"
            : "bg-card border border-border/50 text-card-foreground rounded-tl-sm"
        }`}>
          {/* Attachments for user messages */}
          {isUser && msg.attachments && msg.attachments.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-2">
              {msg.attachments.map((a, i) => (
                a.type === "image" ? (
                  <img key={i} src={a.url} alt={a.name} className="max-h-48 max-w-xs rounded-xl object-cover border border-white/10" />
                ) : (
                  <div key={i} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/10 border border-white/20">
                    <Film className="h-4 w-4" />
                    <span className="text-xs">{a.name}</span>
                  </div>
                )
              ))}
            </div>
          )}
          {msg.isStreaming && !msg.content ? (
            <div className="flex items-center gap-1.5 h-5">
              <span className="typing-dot h-1.5 w-1.5 rounded-full bg-current" />
              <span className="typing-dot h-1.5 w-1.5 rounded-full bg-current" />
              <span className="typing-dot h-1.5 w-1.5 rounded-full bg-current" />
            </div>
          ) : isUser ? (
            <p className="text-sm whitespace-pre-wrap break-words">{msg.content}</p>
          ) : (
            <div className={`text-sm prose-nexus ${msg.isStreaming ? "cursor-blink" : ""}`}>
              <Streamdown>{msg.content}</Streamdown>
            </div>
          )}
        </div>

        {!isUser && msg.steps && msg.steps.length > 0 && (
          <div className="w-full">
            <button
              onClick={() => setStepsExpanded(!stepsExpanded)}
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors mb-1.5 w-full"
            >
              <ChevronRight className={`h-3 w-3 transition-transform ${stepsExpanded ? "rotate-90" : ""}`} />
              <span>{msg.steps.length} reasoning step{msg.steps.length !== 1 ? "s" : ""}</span>
              {msg.toolsUsed && msg.toolsUsed.length > 0 && (
                <span className="text-primary/70">· {msg.toolsUsed.join(", ")}</span>
              )}
              {msg.durationMs && (
                <span className="ml-auto flex items-center gap-1">
                  <Clock className="h-2.5 w-2.5" />
                  {(msg.durationMs / 1000).toFixed(1)}s
                </span>
              )}
            </button>
            <AnimatePresence>
              {stepsExpanded && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-1.5 overflow-hidden"
                >
                  {msg.steps.map((step, i) => <StepCard key={i} step={step} index={i} />)}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {!msg.isStreaming && (
          <div className={`flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity ${isUser ? "flex-row-reverse" : ""}`}>
            <button onClick={handleCopy} className="h-6 w-6 rounded flex items-center justify-center hover:bg-accent transition-colors" title="Copy">
              {copied ? <Check className="h-3 w-3 text-green-400" /> : <Copy className="h-3 w-3 text-muted-foreground" />}
            </button>
            <span className="text-xs text-muted-foreground px-1">
              {new Date(msg.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
            </span>
          </div>
        )}
      </div>
    </motion.div>
  );
}

export default function Chat() {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConvId, setActiveConvId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<{ type: "image" | "video"; url: string; name: string; base64: string; mimeType: string }[]>([]);
  const fileInputRef = useFileRef<HTMLInputElement>(null);
  const uploadMediaMutation = trpc.media.upload.useMutation();
  const [isLoading, setIsLoading] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [editingTitle, setEditingTitle] = useState<number | null>(null);
  const [editTitleValue, setEditTitleValue] = useState("");

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  const convListQuery = trpc.conversations.list.useQuery(undefined, { enabled: !!user });
  const convMessagesQuery = trpc.messages.list.useQuery(
    { conversationId: activeConvId! },
    { enabled: !!activeConvId }
  );
  const createConvMutation = trpc.conversations.create.useMutation();
  const archiveConvMutation = trpc.conversations.archive.useMutation();
  const updateTitleMutation = trpc.conversations.updateTitle.useMutation();
  const utils = trpc.useUtils();

  useEffect(() => {
    if (convListQuery.data) setConversations(convListQuery.data as Conversation[]);
  }, [convListQuery.data]);

  useEffect(() => {
    if (convMessagesQuery.data && activeConvId) {
      const msgs: Message[] = convMessagesQuery.data.map((m: any) => ({
        id: String(m.id),
        role: m.role as "user" | "assistant",
        content: m.content,
        steps: (m.metadata as any)?.steps,
        durationMs: (m.metadata as any)?.durationMs,
        toolsUsed: (m.metadata as any)?.toolsUsed,
        timestamp: new Date(m.createdAt).getTime(),
      }));
      setMessages(msgs);
    }
  }, [convMessagesQuery.data, activeConvId]);

  const scrollToBottom = useCallback((smooth = true) => {
    messagesEndRef.current?.scrollIntoView({ behavior: smooth ? "smooth" : "instant" });
  }, []);

  useEffect(() => {
    if (messages.length > 0) scrollToBottom();
  }, [messages.length, scrollToBottom]);

  const handleNewChat = async () => {
    try {
      const conv = await createConvMutation.mutateAsync({ title: "New Conversation" });
      setActiveConvId(conv.id);
      setMessages([]);
      utils.conversations.list.invalidate();
    } catch { toast.error("Failed to create conversation"); }
  };

  const handleSelectConv = (id: number) => {
    if (isStreaming) return;
    setActiveConvId(id);
    setMessages([]);
  };

  const handleArchive = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    await archiveConvMutation.mutateAsync({ id });
    if (activeConvId === id) { setActiveConvId(null); setMessages([]); }
    utils.conversations.list.invalidate();
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading || !user) return;
    let convId = activeConvId;
    if (!convId) {
      try {
        const conv = await createConvMutation.mutateAsync({ title: "New Conversation" });
        convId = conv.id;
        setActiveConvId(conv.id);
        utils.conversations.list.invalidate();
      } catch { toast.error("Failed to create conversation"); return; }
    }

    const userMsg: Message = { id: `user-${Date.now()}`, role: "user", content: input.trim(), timestamp: Date.now(), attachments: attachments.map(a => ({ type: a.type, url: a.url, name: a.name })) };
    const assistantId = `assistant-${Date.now()}`;
    const assistantMsg: Message = { id: assistantId, role: "assistant", content: "", steps: [], isStreaming: true, timestamp: Date.now() };

    setMessages(prev => [...prev, userMsg, assistantMsg]);
    setInput("");
    setAttachments([]);
    setIsLoading(true);
    setIsStreaming(true);
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    scrollToBottom();

    try {
      const ctrl = new AbortController();
      abortRef.current = ctrl;
      const res = await fetch("/api/agent/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId: convId, message: userMsg.content }),
        signal: ctrl.signal,
        credentials: "include",
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const reader = res.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let currentEvent = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (line.startsWith("event: ")) { currentEvent = line.slice(7).trim(); continue; }
          if (!line.startsWith("data: ")) continue;
          const raw = line.slice(6).trim();
          if (!raw) continue;
          try {
            const event = JSON.parse(raw);
            if (currentEvent === "step" || (event.type && event.title && event.status !== undefined)) {
              setMessages(prev => prev.map(m => {
                if (m.id !== assistantId) return m;
                const existing = m.steps || [];
                const idx = existing.findIndex(s => s.title === event.title && s.type === event.type);
                const newSteps = idx >= 0
                  ? existing.map((s, i) => i === idx ? event : s)
                  : [...existing, event];
                return { ...m, steps: newSteps };
              }));
            } else if (currentEvent === "done" || event.response !== undefined) {
              setMessages(prev => prev.map(m =>
                m.id === assistantId
                  ? { ...m, content: event.response, steps: event.steps || m.steps, durationMs: event.durationMs, toolsUsed: event.toolsUsed, isStreaming: false }
                  : m
              ));
              utils.conversations.list.invalidate();
            } else if (currentEvent === "title") {
              setConversations(prev => prev.map(c => c.id === convId ? { ...c, title: event.title } : c));
            } else if (currentEvent === "error" || event.message) {
              toast.error(event.message || "Agent error");
              setMessages(prev => prev.map(m =>
                m.id === assistantId ? { ...m, content: `Error: ${event.message}`, isStreaming: false } : m
              ));
            }
          } catch { /* ignore */ }
        }
      }
    } catch (err: any) {
      if (err.name !== "AbortError") {
        toast.error("Failed to get response");
        setMessages(prev => prev.map(m =>
          m.id === assistantId ? { ...m, content: "Sorry, I encountered an error. Please try again.", isStreaming: false } : m
        ));
      }
    } finally {
      setIsLoading(false);
      setIsStreaming(false);
      abortRef.current = null;
      utils.conversations.list.invalidate();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const handleTextareaInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 160) + "px";
  };

  const handleAttachFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    for (const file of files) {
      if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) continue;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const dataUrl = ev.target?.result as string;
        const base64 = dataUrl.split(",")[1];
        setAttachments(prev => [...prev, {
          type: file.type.startsWith("video/") ? "video" : "image",
          url: dataUrl,
          name: file.name,
          base64,
          mimeType: file.type,
        }]);
      };
      reader.readAsDataURL(file);
    }
    if (e.target) e.target.value = "";
  };

  const filteredConvs = conversations.filter(c => c.title.toLowerCase().includes(searchQuery.toLowerCase()));

  const handleTitleSave = async (id: number) => {
    if (editTitleValue.trim()) {
      await updateTitleMutation.mutateAsync({ id, title: editTitleValue.trim() });
      setConversations(prev => prev.map(c => c.id === id ? { ...c, title: editTitleValue.trim() } : c));
    }
    setEditingTitle(null);
  };

  return (
    <div className="flex h-full bg-background">
      {/* Conversation Sidebar */}
      <AnimatePresence initial={false}>
        {sidebarOpen && (
          <motion.div
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 256, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="border-r border-border/50 flex flex-col overflow-hidden shrink-0"
          >
            <div className="p-3 border-b border-border/50">
              <Button onClick={handleNewChat} size="sm" className="w-full h-8 text-xs gap-1.5" disabled={isLoading}>
                <Plus className="h-3.5 w-3.5" />New Chat
              </Button>
            </div>
            <div className="px-3 py-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <input
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search chats..."
                  className="w-full h-7 pl-8 pr-3 text-xs bg-muted/50 border border-border/50 rounded-md focus:outline-none focus:ring-1 focus:ring-ring text-foreground placeholder:text-muted-foreground"
                />
              </div>
            </div>
            <ScrollArea className="flex-1 custom-scrollbar">
              <div className="px-2 pb-2 space-y-0.5">
                {filteredConvs.length === 0 ? (
                  <div className="text-center py-8">
                    <MessageSquare className="h-8 w-8 text-muted-foreground/30 mx-auto mb-2" />
                    <p className="text-xs text-muted-foreground">No conversations yet</p>
                  </div>
                ) : filteredConvs.map(conv => (
                  <div
                    key={conv.id}
                    onClick={() => handleSelectConv(conv.id)}
                    className={`group flex items-center gap-2 px-2.5 py-2 rounded-lg cursor-pointer transition-colors ${
                      activeConvId === conv.id
                        ? "bg-primary/10 text-primary"
                        : "hover:bg-accent/50 text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <MessageSquare className="h-3.5 w-3.5 shrink-0" />
                    {editingTitle === conv.id ? (
                      <input
                        value={editTitleValue}
                        onChange={e => setEditTitleValue(e.target.value)}
                        onBlur={() => handleTitleSave(conv.id)}
                        onKeyDown={e => { if (e.key === "Enter") handleTitleSave(conv.id); if (e.key === "Escape") setEditingTitle(null); }}
                        className="flex-1 text-xs bg-transparent border-b border-primary outline-none text-foreground"
                        autoFocus
                        onClick={e => e.stopPropagation()}
                      />
                    ) : (
                      <span className="flex-1 text-xs truncate">{conv.title}</span>
                    )}
                    <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                      <button
                        onClick={e => { e.stopPropagation(); setEditingTitle(conv.id); setEditTitleValue(conv.title); }}
                        className="h-5 w-5 rounded flex items-center justify-center hover:bg-accent"
                      >
                        <PenLine className="h-2.5 w-2.5" />
                      </button>
                      <button
                        onClick={e => handleArchive(conv.id, e)}
                        className="h-5 w-5 rounded flex items-center justify-center hover:bg-destructive/20 hover:text-destructive"
                      >
                        <Trash2 className="h-2.5 w-2.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar */}
        <div className="h-14 border-b border-border/50 flex items-center px-4 gap-3 shrink-0 bg-background/80 backdrop-blur">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="h-8 w-8 rounded-lg flex items-center justify-center hover:bg-accent transition-colors"
          >
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </button>
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <Sparkles className="h-4 w-4 text-primary shrink-0" />
            <span className="text-sm font-semibold text-foreground truncate">
              {activeConvId ? (conversations.find(c => c.id === activeConvId)?.title || "Chat") : "Nexus AI Chat"}
            </span>
          </div>
          {isStreaming && (
            <div className="flex items-center gap-2 text-xs text-primary animate-pulse">
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              <span>Thinking...</span>
            </div>
          )}
        </div>

        {/* Messages */}
        <div
          ref={scrollContainerRef}
          className="flex-1 overflow-y-auto custom-scrollbar px-4 py-6 relative"
          onScroll={e => {
            const el = e.currentTarget;
            setShowScrollBtn(el.scrollHeight - el.scrollTop - el.clientHeight > 200);
          }}
        >
          {messages.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col items-center justify-center min-h-full gap-8 max-w-2xl mx-auto text-center py-12"
            >
              <div>
                <motion.div
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                  className="h-16 w-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-4 glow-primary-sm"
                >
                  <Sparkles className="h-8 w-8 text-primary" />
                </motion.div>
                <h2 className="text-2xl font-bold gradient-text mb-2">What can I help you with?</h2>
                <p className="text-sm text-muted-foreground">
                  I can search the web, write and execute code, analyze data, manage files, and plan complex tasks.
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full">
                {SUGGESTIONS.map((s, i) => (
                  <motion.button
                    key={i}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.07 }}
                    onClick={() => setInput(s)}
                    className="text-left px-4 py-3 rounded-xl border border-border/60 bg-card/50 hover:bg-card hover:border-primary/30 transition-all text-sm text-muted-foreground hover:text-foreground"
                  >
                    <span className="line-clamp-2">{s}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          ) : (
            <div className="max-w-3xl mx-auto space-y-6">
              {messages.map(msg => <MessageBubble key={msg.id} msg={msg} />)}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Scroll to bottom */}
        <AnimatePresence>
          {showScrollBtn && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={() => scrollToBottom()}
              className="fixed bottom-24 right-8 h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors z-10"
            >
              <ChevronDown className="h-4 w-4" />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Input Area */}
        <div className="border-t border-border/50 p-4 bg-background/80 backdrop-blur shrink-0">
          <input ref={fileInputRef} type="file" className="hidden" multiple accept="image/*,video/*" onChange={handleAttachFile} />
          <div className="max-w-3xl mx-auto space-y-2">
            {/* Attachment previews */}
            {attachments.length > 0 && (
              <div className="flex gap-2 flex-wrap">
                {attachments.map((a, i) => (
                  <div key={i} className="relative group">
                    {a.type === "image" ? (
                      <img src={a.url} alt={a.name} className="h-16 w-16 rounded-lg object-cover border border-border/60" />
                    ) : (
                      <div className="h-16 w-16 rounded-lg bg-muted/50 border border-border/60 flex flex-col items-center justify-center gap-1">
                        <Film className="h-6 w-6 text-purple-400" />
                        <span className="text-xs text-muted-foreground truncate w-12 text-center">{a.name}</span>
                      </div>
                    )}
                    <button
                      onClick={() => setAttachments(prev => prev.filter((_, idx) => idx !== i))}
                      className="absolute -top-1.5 -right-1.5 h-4 w-4 rounded-full bg-destructive text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="h-2.5 w-2.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <div className="relative flex items-end gap-2 bg-card border border-border/60 rounded-2xl p-3 focus-within:border-primary/50 focus-within:ring-1 focus-within:ring-primary/20 transition-all">
              <Textarea
                ref={textareaRef}
                value={input}
                onChange={handleTextareaInput}
                onKeyDown={handleKeyDown}
                placeholder="Message Nexus AI... (Enter to send, Shift+Enter for new line)"
                className="flex-1 min-h-[40px] max-h-[160px] resize-none border-0 bg-transparent p-0 focus-visible:ring-0 text-sm placeholder:text-muted-foreground/60 leading-relaxed"
                disabled={isLoading}
              />
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isLoading}
                  className="h-8 w-8 rounded-lg flex items-center justify-center hover:bg-accent text-muted-foreground hover:text-foreground transition-colors disabled:opacity-40"
                  title="Attach image or video"
                >
                  <Paperclip className="h-4 w-4" />
                </button>
                {isStreaming && (
                  <button
                    onClick={() => { abortRef.current?.abort(); setIsStreaming(false); setIsLoading(false); }}
                    className="h-8 w-8 rounded-lg flex items-center justify-center bg-destructive/10 hover:bg-destructive/20 text-destructive transition-colors"
                    title="Stop generation"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className="h-8 w-8 rounded-lg flex items-center justify-center bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
                >
                  {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <p className="text-center text-xs text-muted-foreground/50 mt-2">
              Nexus AI can make mistakes. Verify important information.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
