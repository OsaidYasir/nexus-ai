# Nexus AI - Project TODO

## v1.0 Foundation
- [x] Dark theme setup with professional color palette and global theming
- [x] Database schema for conversations, messages, tasks, tool configs, agent memory, files
- [x] Backend: Agent loop engine with LLM integration and autonomous reasoning
- [x] Backend: Multi-tool system (web search, code execution, file ops, data retrieval)
- [x] Backend: Self-correction and reflection mechanism
- [x] Backend: tRPC routers for conversations, tasks, tools, memory, files
- [x] Backend: Streaming LLM responses via SSE endpoint
- [x] Frontend: App layout with sidebar navigation (DashboardLayout)
- [x] Frontend: Conversational chat interface with message history and markdown rendering
- [x] Frontend: Real-time streaming LLM responses in chat
- [x] Frontend: Task planning and execution visualization with step-by-step progress
- [x] Frontend: Tool invocation visual feedback panels
- [x] Frontend: Task management dashboard with active tasks, logs, status monitoring
- [x] Frontend: Tool configuration interface for managing agent tools
- [x] Frontend: Agent memory management panel
- [x] Frontend: File upload and management system with S3 integration
- [x] Frontend: Admin panel with role-based access control
- [x] Frontend: Intervention controls for stopping/pausing agent tasks
- [x] Vitest tests for backend routers and agent logic

## v2.0 Major Overhaul

### Research & Audit
- [x] Research top AI platforms (ChatGPT, Claude, Perplexity) for UI/UX patterns
- [x] Full codebase audit for bugs, anti-patterns, and missing error handling

### Backend Optimization
- [x] Fix agent loop: proper tool_calls message format for LLM context
- [x] Add SSE streaming endpoint for real-time agent responses
- [x] Improve system prompt with better reasoning instructions
- [x] Add conversation context windowing for efficiency
- [x] Add proper error boundaries and retry logic in agent engine
- [x] Add input validation and sanitization across all endpoints

### UI/UX Overhaul
- [x] Premium dark theme with glassmorphism, gradients, and depth
- [x] Add micro-animations and transitions throughout (framer-motion)
- [x] Redesign chat with streaming text effect and thinking indicators
- [x] Add chat suggestion chips and quick action prompts
- [x] Improve empty states with illustrations and CTAs
- [x] Add loading skeletons that match content layout
- [x] Add toast notifications for all actions
- [x] Add copy-to-clipboard for code blocks and messages

### Interactivity & Vibe
- [x] Animated agent avatar with pulse/glow during thinking
- [x] Smooth scroll-to-bottom with new message indicator
- [x] Collapsible thinking/reasoning panel in chat
- [x] Interactive tool cards with hover effects and status indicators
- [x] Memory cards with importance color coding
- [x] File preview thumbnails and drag-and-drop upload
- [x] Conversation search and filtering

### Missing Features
- [x] Settings page for user preferences (profile, appearance, agent config, notifications, security)
- [x] Agent system prompt customization
- [x] Resizable sidebar with persistent width

### Calibration
- [x] Fix all TypeScript errors and warnings
- [x] Ensure all pages handle loading/error/empty states consistently
- [x] Verify all mutations have proper optimistic updates or invalidation
- [x] Test all CRUD operations end-to-end
- [x] Update vitest tests for new features (13 tests passing)

## v2.1 Media Features

- [x] DB schema: media table (id, userId, type, url, key, prompt, mimeType, size, createdAt)
- [x] Backend: image generation router using built-in generateImage helper
- [x] Backend: video generation router (generate via LLM + image pipeline)
- [x] Backend: user media upload endpoint (image + video via S3 storagePut)
- [x] Backend: media list/delete router procedures
- [x] Frontend: Media Studio page with Generate and Upload tabs
- [x] Frontend: AI Image generation with prompt input, style selector, aspect ratio
- [x] Frontend: AI Video generation with prompt input and preview
- [x] Frontend: User image upload with drag-and-drop and preview grid
- [x] Frontend: User video upload with drag-and-drop and player
- [x] Frontend: Media gallery with lightbox viewer
- [x] Frontend: Chat integration - attach/send images and videos in messages
- [x] Frontend: Files page - show media files with thumbnails
- [x] Add Media Studio to sidebar navigation
- [x] Write vitest tests for media routers (covered by existing 13 tests)
