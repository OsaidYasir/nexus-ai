import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";

// ─── Helpers ─────────────────────────────────────────────────────

type CookieCall = { name: string; options: Record<string, unknown> };
type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createMockUser(overrides: Partial<AuthenticatedUser> = {}): AuthenticatedUser {
  return {
    id: 1,
    openId: "test-user-001",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };
}

function createAdminUser(overrides: Partial<AuthenticatedUser> = {}): AuthenticatedUser {
  return createMockUser({ role: "admin", name: "Admin User", openId: "admin-001", ...overrides });
}

function createAuthContext(user?: AuthenticatedUser): { ctx: TrpcContext; clearedCookies: CookieCall[] } {
  const clearedCookies: CookieCall[] = [];
  const ctx: TrpcContext = {
    user: user || createMockUser(),
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
    } as TrpcContext["res"],
  };
  return { ctx, clearedCookies };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

// ─── Auth Tests ──────────────────────────────────────────────────

describe("auth.me", () => {
  it("returns null for unauthenticated users", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user data for authenticated users", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.me();
    expect(result).not.toBeNull();
    expect(result?.name).toBe("Test User");
    expect(result?.email).toBe("test@example.com");
    expect(result?.role).toBe("user");
  });
});

describe("auth.logout", () => {
  it("clears the session cookie and reports success", async () => {
    const { ctx, clearedCookies } = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
    expect(clearedCookies[0]?.name).toBe(COOKIE_NAME);
    expect(clearedCookies[0]?.options).toMatchObject({ maxAge: -1 });
  });
});

// ─── Agent Tools Tests ───────────────────────────────────────────

describe("agent.tools", () => {
  it("returns list of built-in tools", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const tools = await caller.agent.tools();
    expect(Array.isArray(tools)).toBe(true);
    expect(tools.length).toBeGreaterThan(0);

    // Verify tool structure
    for (const tool of tools) {
      expect(tool).toHaveProperty("name");
      expect(tool).toHaveProperty("description");
      expect(typeof tool.name).toBe("string");
      expect(typeof tool.description).toBe("string");
    }
  });

  it("includes expected built-in tools", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const tools = await caller.agent.tools();
    const toolNames = tools.map((t) => t.name);

    expect(toolNames).toContain("web_search");
    expect(toolNames).toContain("execute_code");
    expect(toolNames).toContain("read_file");
    expect(toolNames).toContain("write_file");
    expect(toolNames).toContain("analyze_data");
    expect(toolNames).toContain("create_plan");
  });
});

// ─── Protected Route Tests ───────────────────────────────────────

describe("protected routes", () => {
  it("conversations.list requires authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.conversations.list()).rejects.toThrow();
  });

  it("tasks.list requires authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.tasks.list()).rejects.toThrow();
  });

  it("memory.list requires authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.memory.list()).rejects.toThrow();
  });

  it("files.list requires authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.files.list()).rejects.toThrow();
  });

  it("toolConfigs.list requires authentication", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.toolConfigs.list()).rejects.toThrow();
  });
});

// ─── Admin Route Tests ───────────────────────────────────────────

describe("admin routes", () => {
  it("admin.stats requires admin role", async () => {
    const { ctx } = createAuthContext(createMockUser({ role: "user" }));
    const caller = appRouter.createCaller(ctx);
    await expect(caller.admin.stats()).rejects.toThrow();
  });

  it("admin.stats accessible by admin users", async () => {
    const { ctx } = createAuthContext(createAdminUser());
    const caller = appRouter.createCaller(ctx);
    // This will try to hit the DB, which may not be available in test
    // So we just verify it doesn't throw an auth error
    try {
      const result = await caller.admin.stats();
      expect(result).toHaveProperty("users");
      expect(result).toHaveProperty("conversations");
      expect(result).toHaveProperty("tasks");
      expect(result).toHaveProperty("files");
    } catch (error: any) {
      // If it fails, it should NOT be an auth error
      expect(error.code).not.toBe("UNAUTHORIZED");
      expect(error.code).not.toBe("FORBIDDEN");
    }
  });
});
