import type { Request, Response } from "express";
import { sdk } from "./_core/sdk";
import * as db from "./db";
import { runAgent, generateTitle, type AgentStep } from "./agent";

/**
 * SSE endpoint for streaming agent chat responses.
 * POST /api/agent/stream
 * Body: { conversationId: number, message: string }
 *
 * Events:
 *   step   - Agent step updates (thinking, tool_call, tool_result, etc.)
 *   token  - Streamed response tokens (for future real streaming)
 *   done   - Final response with all steps
 *   error  - Error message
 */
export async function handleAgentStream(req: Request, res: Response) {
  // Authenticate
  let user;
  try {
    user = await sdk.authenticateRequest(req);
  } catch {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const { conversationId, message } = req.body;
  if (!conversationId || !message) {
    res.status(400).json({ error: "conversationId and message are required" });
    return;
  }

  // Set SSE headers
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no",
  });

  const sendEvent = (event: string, data: unknown) => {
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  try {
    // Save user message
    await db.addMessage({
      conversationId,
      role: "user",
      content: message,
    });

    sendEvent("step", {
      type: "thinking",
      title: "Analyzing your request",
      content: "Understanding intent and planning approach...",
      status: "running",
      timestamp: Date.now(),
    });

    // Run agent with step callbacks
    const result = await runAgent(
      conversationId,
      message,
      user.id,
      (step: AgentStep) => {
        sendEvent("step", step);
      }
    );

    // Save assistant response
    await db.addMessage({
      conversationId,
      role: "assistant",
      content: result.response,
      metadata: {
        steps: result.steps,
        durationMs: result.totalDurationMs,
        toolsUsed: result.toolsUsed,
        iterations: result.iterationCount,
      },
    });

    // Auto-generate title for first message
    const messages = await db.getConversationMessages(conversationId);
    const userMessages = messages.filter(m => m.role === "user");
    if (userMessages.length === 1) {
      const title = await generateTitle(message);
      await db.updateConversationTitle(conversationId, title);
      sendEvent("title", { title });
    }

    // Send final response
    sendEvent("done", {
      response: result.response,
      steps: result.steps,
      durationMs: result.totalDurationMs,
      toolsUsed: result.toolsUsed,
      iterations: result.iterationCount,
    });
  } catch (error) {
    const msg = error instanceof Error ? error.message : "Unknown error";
    sendEvent("error", { message: msg });
  } finally {
    res.end();
  }
}
