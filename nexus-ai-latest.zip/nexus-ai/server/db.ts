import { eq, desc, and, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users,
  conversations, InsertConversation,
  messages, InsertMessage,
  tasks, InsertTask,
  taskSteps, InsertTaskStep,
  toolConfigs, InsertToolConfig,
  agentMemories, InsertAgentMemory,
  files, InsertFile,
  mediaItems, InsertMediaItem,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ───────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];
  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; } else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Conversations ───────────────────────────────────────────────
export async function createConversation(data: InsertConversation) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(conversations).values(data);
  const id = result[0].insertId;
  const rows = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return rows[0];
}

export async function getUserConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(conversations).where(and(eq(conversations.userId, userId), eq(conversations.status, "active"))).orderBy(desc(conversations.updatedAt));
}

export async function getConversationById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(conversations).where(and(eq(conversations.id, id), eq(conversations.userId, userId))).limit(1);
  return rows[0];
}

export async function updateConversationTitle(id: number, title: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(conversations).set({ title }).where(eq(conversations.id, id));
}

export async function archiveConversation(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(conversations).set({ status: "archived" }).where(eq(conversations.id, id));
}

// ─── Messages ────────────────────────────────────────────────────
export async function addMessage(data: InsertMessage) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(messages).values(data);
  const id = result[0].insertId;
  const rows = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
  return rows[0];
}

export async function getConversationMessages(conversationId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(messages).where(eq(messages.conversationId, conversationId)).orderBy(messages.createdAt);
}

// ─── Tasks ───────────────────────────────────────────────────────
export async function createTask(data: InsertTask) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(tasks).values(data);
  const id = result[0].insertId;
  const rows = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
  return rows[0];
}

export async function getUserTasks(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(tasks).where(eq(tasks.userId, userId)).orderBy(desc(tasks.createdAt));
}

export async function getTaskById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
  return rows[0];
}

export async function updateTaskStatus(id: number, status: string, extra?: { result?: string; errorMessage?: string }) {
  const db = await getDb();
  if (!db) return;
  const set: Record<string, unknown> = { status };
  if (status === "running") set.startedAt = new Date();
  if (status === "completed" || status === "failed") set.completedAt = new Date();
  if (extra?.result) set.result = extra.result;
  if (extra?.errorMessage) set.errorMessage = extra.errorMessage;
  await db.update(tasks).set(set).where(eq(tasks.id, id));
}

export async function cancelTask(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(tasks).set({ status: "cancelled", completedAt: new Date() }).where(eq(tasks.id, id));
}

// ─── Task Steps ──────────────────────────────────────────────────
export async function addTaskStep(data: InsertTaskStep) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(taskSteps).values(data);
  const id = result[0].insertId;
  const rows = await db.select().from(taskSteps).where(eq(taskSteps.id, id)).limit(1);
  return rows[0];
}

export async function getTaskSteps(taskId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(taskSteps).where(eq(taskSteps.taskId, taskId)).orderBy(taskSteps.stepNumber);
}

export async function updateTaskStep(id: number, data: Partial<InsertTaskStep>) {
  const db = await getDb();
  if (!db) return;
  await db.update(taskSteps).set(data).where(eq(taskSteps.id, id));
}

// ─── Tool Configs ────────────────────────────────────────────────
export async function getUserToolConfigs(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(toolConfigs).where(eq(toolConfigs.userId, userId)).orderBy(toolConfigs.name);
}

export async function createToolConfig(data: InsertToolConfig) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(toolConfigs).values(data);
  const id = result[0].insertId;
  const rows = await db.select().from(toolConfigs).where(eq(toolConfigs.id, id)).limit(1);
  return rows[0];
}

export async function updateToolConfig(id: number, data: Partial<InsertToolConfig>) {
  const db = await getDb();
  if (!db) return;
  await db.update(toolConfigs).set(data).where(eq(toolConfigs.id, id));
}

export async function deleteToolConfig(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(toolConfigs).where(eq(toolConfigs.id, id));
}

// ─── Agent Memory ────────────────────────────────────────────────
export async function getUserMemories(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(agentMemories).where(eq(agentMemories.userId, userId)).orderBy(desc(agentMemories.updatedAt));
}

export async function addMemory(data: InsertAgentMemory) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(agentMemories).values(data);
  const id = result[0].insertId;
  const rows = await db.select().from(agentMemories).where(eq(agentMemories.id, id)).limit(1);
  return rows[0];
}

export async function updateMemory(id: number, data: Partial<InsertAgentMemory>) {
  const db = await getDb();
  if (!db) return;
  await db.update(agentMemories).set(data).where(eq(agentMemories.id, id));
}

export async function deleteMemory(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(agentMemories).where(eq(agentMemories.id, id));
}

// ─── Files ───────────────────────────────────────────────────────
export async function addFile(data: InsertFile) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(files).values(data);
  const id = result[0].insertId;
  const rows = await db.select().from(files).where(eq(files.id, id)).limit(1);
  return rows[0];
}

export async function getUserFiles(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(files).where(eq(files.userId, userId)).orderBy(desc(files.createdAt));
}

export async function deleteFile(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(files).where(eq(files.id, id));
}

// ─── Media Items ─────────────────────────────────────────────────
export async function addMediaItem(data: InsertMediaItem) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(mediaItems).values(data);
  const id = result[0].insertId;
  const rows = await db.select().from(mediaItems).where(eq(mediaItems.id, id)).limit(1);
  return rows[0];
}

export async function getUserMediaItems(userId: number, type?: 'image' | 'video') {
  const db = await getDb();
  if (!db) return [];
  const base = db.select().from(mediaItems).where(eq(mediaItems.userId, userId));
  if (type) {
    return db.select().from(mediaItems)
      .where(and(eq(mediaItems.userId, userId), eq(mediaItems.type, type)))
      .orderBy(desc(mediaItems.createdAt));
  }
  return base.orderBy(desc(mediaItems.createdAt));
}

export async function getMediaItemById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(mediaItems).where(eq(mediaItems.id, id)).limit(1);
  return rows[0];
}

export async function deleteMediaItem(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(mediaItems).where(eq(mediaItems.id, id));
}

export async function updateMediaItemStatus(id: number, status: 'pending' | 'processing' | 'completed' | 'failed', url?: string) {
  const db = await getDb();
  if (!db) return;
  const updates: Record<string, unknown> = { status };
  if (url) updates.url = url;
  await db.update(mediaItems).set(updates).where(eq(mediaItems.id, id));
}
