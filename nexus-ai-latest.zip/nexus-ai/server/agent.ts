import { invokeLLM, type Message as LLMMessage, type Tool, type ToolCall } from "./_core/llm";
import * as db from "./db";

// ─── Tool Definitions ────────────────────────────────────────────
export const BUILT_IN_TOOLS: Tool[] = [
  {
    type: "function",
    function: {
      name: "web_search",
      description: "Search the web for current information on any topic. Returns relevant search results with titles, snippets, and URLs. Use this when you need up-to-date information or facts you're unsure about.",
      parameters: {
        type: "object",
        properties: {
          query: { type: "string", description: "The search query to find information about" },
        },
        required: ["query"],
        additionalProperties: false,
      },
    },
  },
  {
    type: "function",
    function: {
      name: "execute_code",
      description: "Execute code in a sandboxed environment. Use this for calculations, data processing, generating outputs, or testing logic. Returns stdout, stderr, and exit code.",
      parameters: {
        type: "object",
        properties: {
          language: { type: "string", enum: ["python", "javascript"], description: "Programming language to use" },
          code: { type: "string", description: "The code to execute" },
        },
        required: ["language", "code"],
        additionalProperties: false,
      },
    },
  },
  {
    type: "function",
    function: {
      name: "read_file",
      description: "Read the contents of an uploaded file by its filename. Use this to examine documents, data files, or any uploaded content.",
      parameters: {
        type: "object",
        properties: {
          filename: { type: "string", description: "Name of the file to read" },
        },
        required: ["filename"],
        additionalProperties: false,
      },
    },
  },
  {
    type: "function",
    function: {
      name: "write_file",
      description: "Create or overwrite a file with the given content. Use this to save results, generate reports, or create output files.",
      parameters: {
        type: "object",
        properties: {
          filename: { type: "string", description: "Name of the file to create or overwrite" },
          content: { type: "string", description: "Content to write to the file" },
        },
        required: ["filename", "content"],
        additionalProperties: false,
      },
    },
  },
  {
    type: "function",
    function: {
      name: "analyze_data",
      description: "Analyze structured data and return insights. Provide data in JSON or CSV format along with the type of analysis needed.",
      parameters: {
        type: "object",
        properties: {
          data: { type: "string", description: "The data to analyze in JSON or CSV format" },
          analysis_type: {
            type: "string",
            enum: ["summary", "statistics", "trends", "correlations", "anomalies"],
            description: "Type of analysis to perform",
          },
          question: { type: "string", description: "Specific question to answer about the data" },
        },
        required: ["data", "analysis_type"],
        additionalProperties: false,
      },
    },
  },
  {
    type: "function",
    function: {
      name: "create_plan",
      description: "Create a structured execution plan for a complex task. Breaks down the goal into actionable subtasks with dependencies and priorities.",
      parameters: {
        type: "object",
        properties: {
          goal: { type: "string", description: "The high-level goal to plan for" },
          constraints: { type: "string", description: "Any constraints, deadlines, or requirements to consider" },
          context: { type: "string", description: "Additional context about the situation" },
        },
        required: ["goal"],
        additionalProperties: false,
      },
    },
  },
];

// ─── Tool Execution (Simulated) ──────────────────────────────────
async function executeTool(name: string, args: Record<string, unknown>): Promise<string> {
  const startTime = Date.now();

  switch (name) {
    case "web_search": {
      const query = args.query as string;
      return JSON.stringify({
        query,
        results: [
          {
            title: `Top results for: ${query}`,
            snippet: `Comprehensive findings about "${query}". Multiple authoritative sources confirm the key details. The latest data shows significant developments in this area.`,
            url: `https://search.example.com/results?q=${encodeURIComponent(query)}`,
            relevance: 0.95,
          },
          {
            title: `${query} - In-Depth Analysis`,
            snippet: `Detailed analysis and background context for "${query}". Expert opinions and recent studies provide additional perspective on this topic.`,
            url: `https://analysis.example.com/${encodeURIComponent(query)}`,
            relevance: 0.87,
          },
          {
            title: `Related: ${query} - Latest Updates`,
            snippet: `Recent developments and updates related to "${query}". New findings from Q1 2026 suggest evolving trends in this space.`,
            url: `https://news.example.com/${encodeURIComponent(query)}`,
            relevance: 0.82,
          },
        ],
        totalResults: 3,
        searchTime: `${Date.now() - startTime}ms`,
      });
    }
    case "execute_code": {
      const lang = args.language as string;
      const code = args.code as string;
      // Simulate realistic code execution
      const lines = code.split("\n").filter(l => l.trim()).length;
      return JSON.stringify({
        language: lang,
        stdout: `[${lang} sandbox] Executed ${lines} lines successfully.\n` +
          (code.includes("print") || code.includes("console.log")
            ? "Output: Computation complete. Results generated.\n"
            : "No output produced.\n"),
        stderr: "",
        exitCode: 0,
        executionTime: `${Math.max(50, Date.now() - startTime)}ms`,
        memoryUsed: `${Math.round(Math.random() * 50 + 10)}MB`,
      });
    }
    case "read_file": {
      return JSON.stringify({
        filename: args.filename,
        content: `[Contents of ${args.filename}]\nFile loaded successfully. Contains structured data ready for processing.`,
        size: `${Math.round(Math.random() * 100 + 1)}KB`,
        encoding: "utf-8",
        lastModified: new Date().toISOString(),
      });
    }
    case "write_file": {
      const content = args.content as string;
      return JSON.stringify({
        filename: args.filename,
        status: "created",
        size: `${content.length} bytes`,
        path: `/workspace/${args.filename}`,
        timestamp: new Date().toISOString(),
      });
    }
    case "analyze_data": {
      const analysisType = args.analysis_type as string;
      return JSON.stringify({
        analysisType,
        question: args.question || null,
        summary: `${analysisType.charAt(0).toUpperCase() + analysisType.slice(1)} analysis completed successfully.`,
        insights: [
          "Primary pattern: Strong positive trend identified in the dataset",
          "Key finding: Statistical significance (p < 0.05) found in primary variables",
          "Notable: Correlation coefficient of 0.84 between key metrics",
          analysisType === "anomalies" ? "2 potential anomalies detected in the dataset" : "Data distribution follows expected patterns",
        ],
        metrics: {
          recordsAnalyzed: Math.round(Math.random() * 1000 + 100),
          processingTime: `${Date.now() - startTime}ms`,
          confidence: 0.92,
        },
      });
    }
    case "create_plan": {
      const goal = args.goal as string;
      return JSON.stringify({
        goal,
        constraints: args.constraints || "None specified",
        plan: {
          phases: [
            {
              phase: 1,
              title: "Research & Discovery",
              tasks: ["Gather requirements", "Research existing solutions", "Identify constraints"],
              duration: "1-2 days",
              status: "ready",
            },
            {
              phase: 2,
              title: "Analysis & Design",
              tasks: ["Analyze findings", "Design solution architecture", "Create specifications"],
              duration: "2-3 days",
              status: "pending",
              dependsOn: [1],
            },
            {
              phase: 3,
              title: "Implementation",
              tasks: ["Build core components", "Integrate systems", "Initial testing"],
              duration: "3-5 days",
              status: "pending",
              dependsOn: [2],
            },
            {
              phase: 4,
              title: "Review & Refinement",
              tasks: ["Quality assurance", "Performance optimization", "Final review"],
              duration: "1-2 days",
              status: "pending",
              dependsOn: [3],
            },
          ],
          estimatedTotal: "7-12 days",
          riskLevel: "medium",
        },
      });
    }
    default:
      return JSON.stringify({ error: `Unknown tool: ${name}`, suggestion: "Check available tools and try again." });
  }
}

// ─── Agent Loop Types ────────────────────────────────────────────
export type AgentStep = {
  type: "thinking" | "tool_call" | "tool_result" | "reflection" | "answer";
  title: string;
  content: string;
  toolName?: string;
  toolInput?: Record<string, unknown>;
  toolOutput?: string;
  status: "pending" | "running" | "completed" | "failed";
  durationMs?: number;
  timestamp: number;
};

export type AgentRunResult = {
  response: string;
  steps: AgentStep[];
  totalDurationMs: number;
  toolsUsed: string[];
  iterationCount: number;
};

// ─── System Prompt ───────────────────────────────────────────────
function buildSystemPrompt(memories: string[]): string {
  let prompt = `You are Nexus, an advanced autonomous AI agent built for complex reasoning, task planning, and tool use.

## Core Identity
You are precise, thorough, and proactive. You break down complex problems, use tools strategically, and deliver well-structured, actionable responses.

## Capabilities
- **Reasoning**: Multi-step logical analysis, pattern recognition, and inference
- **Tool Use**: Web search, code execution, file operations, data analysis, and planning
- **Self-Reflection**: Evaluate your own outputs and correct mistakes before responding
- **Memory**: Access to user context and preferences from previous interactions

## Behavioral Guidelines
1. **Think before acting**: Always reason through the problem before using tools
2. **Be strategic with tools**: Only use tools when they genuinely add value to your response
3. **Be precise**: Provide specific, actionable answers with evidence when possible
4. **Structure output**: Use markdown formatting — headers, lists, code blocks, tables — for clarity
5. **Acknowledge uncertainty**: Be transparent about confidence levels and limitations
6. **Be concise but complete**: Don't pad responses, but don't omit important details

## Response Format
- Use markdown for all responses
- Include code blocks with language tags for any code
- Use tables for comparative data
- Bold key terms and findings
- Use headers to organize longer responses`;

  if (memories.length > 0) {
    prompt += `\n\n## User Context (from memory)\n${memories.join("\n")}`;
  }

  return prompt;
}

// ─── Main Agent Loop ─────────────────────────────────────────────
export async function runAgent(
  conversationId: number,
  userMessage: string,
  userId: number,
  onStep?: (step: AgentStep) => void
): Promise<AgentRunResult> {
  const startTime = Date.now();
  const steps: AgentStep[] = [];
  const toolsUsed: string[] = [];

  // 1. Load context
  const history = await db.getConversationMessages(conversationId);
  const memories = await db.getUserMemories(userId);
  const memoryStrings = memories.map(m => `- [${m.type}] ${m.key}: ${m.value}`);

  // 2. Build message array
  const llmMessages: LLMMessage[] = [
    { role: "system", content: buildSystemPrompt(memoryStrings) },
  ];

  // Add conversation history (last 20 messages for context window efficiency)
  const recentHistory = history.slice(-20);
  for (const msg of recentHistory) {
    if (msg.role === "system") continue;
    llmMessages.push({
      role: msg.role as "user" | "assistant",
      content: msg.content,
    });
  }

  // Add current user message
  llmMessages.push({ role: "user", content: userMessage });

  // 3. Thinking step
  const thinkingStep: AgentStep = {
    type: "thinking",
    title: "Analyzing your request",
    content: "Understanding the intent and determining the best approach...",
    status: "running",
    timestamp: Date.now(),
  };
  steps.push(thinkingStep);
  onStep?.(thinkingStep);

  // 4. Agent loop (max 6 iterations for tool use chains)
  let finalResponse = "";
  let iterations = 0;
  const maxIterations = 6;

  while (iterations < maxIterations) {
    iterations++;

    try {
      const result = await invokeLLM({
        messages: llmMessages,
        tools: BUILT_IN_TOOLS,
        tool_choice: "auto",
      });

      const choice = result.choices[0];
      if (!choice) {
        thinkingStep.status = "failed";
        thinkingStep.content = "No response received from the model.";
        break;
      }

      const assistantMessage = choice.message;

      // Check for tool calls
      if (assistantMessage.tool_calls && assistantMessage.tool_calls.length > 0) {
        // Update thinking step
        thinkingStep.status = "completed";
        thinkingStep.durationMs = Date.now() - startTime;
        thinkingStep.content = assistantMessage.content
          ? (typeof assistantMessage.content === "string" ? assistantMessage.content : "")
          : "Decided to use tools to provide a better answer.";

        // Add assistant message with tool_calls to context (critical for API format)
        llmMessages.push({
          role: "assistant",
          content: assistantMessage.content || "",
        });

        for (const toolCall of assistantMessage.tool_calls) {
          const toolName = toolCall.function.name;
          let toolArgs: Record<string, unknown> = {};
          try {
            toolArgs = JSON.parse(toolCall.function.arguments);
          } catch { /* empty */ }

          if (!toolsUsed.includes(toolName)) toolsUsed.push(toolName);

          // Tool call step
          const toolStep: AgentStep = {
            type: "tool_call",
            title: formatToolTitle(toolName),
            content: formatToolDescription(toolName, toolArgs),
            toolName,
            toolInput: toolArgs,
            status: "running",
            timestamp: Date.now(),
          };
          steps.push(toolStep);
          onStep?.(toolStep);

          // Execute tool
          const toolStartTime = Date.now();
          let toolOutput: string;
          try {
            toolOutput = await executeTool(toolName, toolArgs);
            toolStep.status = "completed";
          } catch (err) {
            toolOutput = JSON.stringify({ error: err instanceof Error ? err.message : "Tool execution failed" });
            toolStep.status = "failed";
          }
          toolStep.toolOutput = toolOutput;
          toolStep.durationMs = Date.now() - toolStartTime;

          // Tool result step
          const resultStep: AgentStep = {
            type: "tool_result",
            title: `Result: ${formatToolTitle(toolName)}`,
            content: toolOutput,
            toolName,
            toolOutput,
            status: toolStep.status,
            durationMs: toolStep.durationMs,
            timestamp: Date.now(),
          };
          steps.push(resultStep);
          onStep?.(resultStep);

          // Add tool result to messages for next LLM call
          llmMessages.push({
            role: "tool",
            content: toolOutput,
            tool_call_id: toolCall.id,
            name: toolName,
          });
        }

        // Continue loop to let LLM process tool results
        continue;
      }

      // No tool calls — this is the final response
      thinkingStep.status = "completed";
      thinkingStep.durationMs = Date.now() - startTime;

      finalResponse = typeof assistantMessage.content === "string"
        ? assistantMessage.content
        : Array.isArray(assistantMessage.content)
          ? assistantMessage.content.map(c => "text" in c ? c.text : "").join("")
          : "";

      break;
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : "Unknown error";

      // Reflection step on error
      const reflectionStep: AgentStep = {
        type: "reflection",
        title: "Self-correction",
        content: `Encountered an issue: ${errorMsg}. Adjusting approach...`,
        status: "completed",
        timestamp: Date.now(),
      };
      steps.push(reflectionStep);
      onStep?.(reflectionStep);

      if (iterations >= maxIterations) {
        finalResponse = "I encountered an issue while processing your request. Let me provide what I can based on my current knowledge.\n\n" +
          `**Error**: ${errorMsg}`;
        break;
      }
    }
  }

  // 5. Answer step
  const answerStep: AgentStep = {
    type: "answer",
    title: "Response ready",
    content: finalResponse.substring(0, 200) + (finalResponse.length > 200 ? "..." : ""),
    status: "completed",
    durationMs: Date.now() - startTime,
    timestamp: Date.now(),
  };
  steps.push(answerStep);
  onStep?.(answerStep);

  return {
    response: finalResponse,
    steps,
    totalDurationMs: Date.now() - startTime,
    toolsUsed,
    iterationCount: iterations,
  };
}

// ─── Helper Functions ───────────────────────────────────────────
function formatToolTitle(toolName: string): string {
  const titles: Record<string, string> = {
    web_search: "Searching the web",
    execute_code: "Running code",
    read_file: "Reading file",
    write_file: "Writing file",
    analyze_data: "Analyzing data",
    create_plan: "Creating plan",
  };
  return titles[toolName] || `Using ${toolName}`;
}

function formatToolDescription(toolName: string, args: Record<string, unknown>): string {
  switch (toolName) {
    case "web_search":
      return `Searching for: "${args.query}"`;
    case "execute_code":
      return `Executing ${args.language} code (${((args.code as string) || "").split("\n").length} lines)`;
    case "read_file":
      return `Reading file: ${args.filename}`;
    case "write_file":
      return `Writing to: ${args.filename}`;
    case "analyze_data":
      return `Running ${args.analysis_type} analysis`;
    case "create_plan":
      return `Planning: ${args.goal}`;
    default:
      return `Executing ${toolName}`;
  }
}

// ─── Auto-title Generation ──────────────────────────────────────
export async function generateTitle(userMessage: string): Promise<string> {
  try {
    const result = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "Generate a short, descriptive title (3-6 words) for a conversation that starts with the following message. Return ONLY the title text, no quotes, no punctuation at the end.",
        },
        { role: "user", content: userMessage },
      ],
    });
    const title = typeof result.choices[0]?.message?.content === "string"
      ? result.choices[0].message.content.trim().replace(/^["']|["']$/g, "").replace(/\.+$/, "")
      : "New Conversation";
    return title.substring(0, 100);
  } catch {
    return userMessage.substring(0, 50) + (userMessage.length > 50 ? "..." : "");
  }
}
