import { COOKIE_NAME } from "../shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, adminProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { runAgent, generateTitle, BUILT_IN_TOOLS, type AgentStep } from "./agent";
import { storagePut } from "./storage";
import { generateImage } from "./_core/imageGeneration";
import { invokeLLM } from "./_core/llm";
import { nanoid } from "nanoid";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Conversations ─────────────────────────────────────────────
  conversations: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserConversations(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        return db.getConversationById(input.id, ctx.user.id);
      }),

    create: protectedProcedure
      .input(z.object({ title: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        return db.createConversation({
          userId: ctx.user.id,
          title: input.title || "New Conversation",
        });
      }),

    updateTitle: protectedProcedure
      .input(z.object({ id: z.number(), title: z.string() }))
      .mutation(async ({ input }) => {
        await db.updateConversationTitle(input.id, input.title);
        return { success: true };
      }),

    archive: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.archiveConversation(input.id);
        return { success: true };
      }),
  }),

  // ─── Messages ──────────────────────────────────────────────────
  messages: router({
    list: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ input }) => {
        return db.getConversationMessages(input.conversationId);
      }),
  }),

  // ─── Agent (Chat + Autonomous Execution) ───────────────────────
  agent: router({
    chat: protectedProcedure
      .input(z.object({
        conversationId: z.number(),
        message: z.string().min(1),
      }))
      .mutation(async ({ ctx, input }) => {
        // Save user message
        await db.addMessage({
          conversationId: input.conversationId,
          role: "user",
          content: input.message,
        });

        // Run agent loop
        const allSteps: AgentStep[] = [];
        const result = await runAgent(
          input.conversationId,
          input.message,
          ctx.user.id,
          (step) => allSteps.push(step)
        );

        // Save assistant response
        await db.addMessage({
          conversationId: input.conversationId,
          role: "assistant",
          content: result.response,
          metadata: { steps: result.steps, durationMs: result.totalDurationMs },
        });

        // Save task steps to DB
        const conv = await db.getConversationById(input.conversationId, ctx.user.id);
        if (conv) {
          // Auto-generate title for new conversations
          const messages = await db.getConversationMessages(input.conversationId);
          if (messages.filter(m => m.role === "user").length === 1) {
            const title = await generateTitle(input.message);
            await db.updateConversationTitle(input.conversationId, title);
          }
        }

        return {
          response: result.response,
          steps: result.steps,
          durationMs: result.totalDurationMs,
        };
      }),

    // Get available tools
    tools: publicProcedure.query(() => {
      return BUILT_IN_TOOLS.map(t => ({
        name: t.function.name,
        description: t.function.description,
        parameters: t.function.parameters,
      }));
    }),
  }),

  // ─── Tasks ─────────────────────────────────────────────────────
  tasks: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserTasks(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getTaskById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
        conversationId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createTask({
          userId: ctx.user.id,
          title: input.title,
          description: input.description,
          priority: input.priority || "medium",
          conversationId: input.conversationId,
        });
      }),

    execute: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const task = await db.getTaskById(input.id);
        if (!task) throw new Error("Task not found");

        await db.updateTaskStatus(input.id, "running");

        try {
          // Create a temporary conversation for task execution
          const conv = await db.createConversation({
            userId: ctx.user.id,
            title: `Task: ${task.title}`,
          });

          const stepNum = { current: 0 };
          const result = await runAgent(
            conv.id,
            task.description || task.title,
            ctx.user.id,
            async (step) => {
              stepNum.current++;
              await db.addTaskStep({
                taskId: input.id,
                stepNumber: stepNum.current,
                type: step.type,
                title: step.title,
                content: step.content,
                toolName: step.toolName,
                toolInput: step.toolInput,
                toolOutput: step.toolOutput,
                status: step.status,
                durationMs: step.durationMs,
              });
            }
          );

          await db.updateTaskStatus(input.id, "completed", { result: result.response });
          return { success: true, result: result.response, steps: result.steps };
        } catch (error) {
          const msg = error instanceof Error ? error.message : "Unknown error";
          await db.updateTaskStatus(input.id, "failed", { errorMessage: msg });
          throw error;
        }
      }),

    cancel: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.cancelTask(input.id);
        return { success: true };
      }),

    steps: protectedProcedure
      .input(z.object({ taskId: z.number() }))
      .query(async ({ input }) => {
        return db.getTaskSteps(input.taskId);
      }),
  }),

  // ─── Tool Configuration ────────────────────────────────────────
  toolConfigs: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserToolConfigs(ctx.user.id);
    }),

    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        displayName: z.string(),
        description: z.string().optional(),
        category: z.enum(["search", "code", "file", "data", "custom"]).optional(),
        icon: z.string().optional(),
        config: z.record(z.string(), z.unknown()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.createToolConfig({
          userId: ctx.user.id,
          name: input.name,
          displayName: input.displayName,
          description: input.description,
          category: input.category || "custom",
          icon: input.icon || "wrench",
          config: input.config,
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        displayName: z.string().optional(),
        description: z.string().optional(),
        enabled: z.boolean().optional(),
        config: z.record(z.string(), z.unknown()).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateToolConfig(id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteToolConfig(input.id);
        return { success: true };
      }),
  }),

  // ─── Agent Memory ──────────────────────────────────────────────
  memory: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserMemories(ctx.user.id);
    }),

    add: protectedProcedure
      .input(z.object({
        type: z.enum(["fact", "preference", "behavior", "context"]).optional(),
        key: z.string(),
        value: z.string(),
        source: z.string().optional(),
        importance: z.enum(["low", "medium", "high"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return db.addMemory({
          userId: ctx.user.id,
          type: input.type || "fact",
          key: input.key,
          value: input.value,
          source: input.source,
          importance: input.importance || "medium",
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        value: z.string().optional(),
        importance: z.enum(["low", "medium", "high"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateMemory(id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteMemory(input.id);
        return { success: true };
      }),
  }),

  // ─── File Management ──────────────────────────────────────────
  files: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserFiles(ctx.user.id);
    }),

    upload: protectedProcedure
      .input(z.object({
        filename: z.string(),
        mimeType: z.string(),
        size: z.number(),
        base64Data: z.string(),
        conversationId: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const buffer = Buffer.from(input.base64Data, "base64");
        const fileKey = `${ctx.user.id}-files/${nanoid()}-${input.filename}`;
        const { url } = await storagePut(fileKey, buffer, input.mimeType);

        return db.addFile({
          userId: ctx.user.id,
          filename: input.filename,
          mimeType: input.mimeType,
          size: input.size,
          url,
          fileKey,
          conversationId: input.conversationId,
        });
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteFile(input.id);
        return { success: true };
      }),
  }),

  // ─── Dashboard ───────────────────────────────────────────────
  dashboard: router({
    stats: protectedProcedure.query(async ({ ctx }) => {
      const convs = await db.getUserConversations(ctx.user.id);
      const tasks = await db.getUserTasks(ctx.user.id);
      const memories = await db.getUserMemories(ctx.user.id);
      const files = await db.getUserFiles(ctx.user.id);
      return {
        totalConversations: convs.length,
        completedTasks: tasks.filter((t: any) => t.status === 'completed').length,
        activeTools: 6,
        memoryEntries: memories.length,
        totalFiles: files.length,
        totalTasks: tasks.length,
      };
    }),

    recentActivity: protectedProcedure.query(async ({ ctx }) => {
      const convs = await db.getUserConversations(ctx.user.id);
      const tasks = await db.getUserTasks(ctx.user.id);
      const files = await db.getUserFiles(ctx.user.id);

      const now = Date.now();
      const timeAgo = (date: Date) => {
        const diff = now - new Date(date).getTime();
        if (diff < 60000) return 'just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
        return `${Math.floor(diff / 86400000)}d ago`;
      };

      const activity = [
        ...convs.slice(0, 4).map((c: any) => ({
          type: 'conversation', title: c.title, subtitle: 'Conversation',
          timeAgo: timeAgo(c.updatedAt), status: null,
        })),
        ...tasks.slice(0, 4).map((t: any) => ({
          type: 'task', title: t.title, subtitle: 'Task',
          timeAgo: timeAgo(t.updatedAt), status: t.status,
        })),
        ...files.slice(0, 2).map((f: any) => ({
          type: 'file', title: f.filename, subtitle: 'File uploaded',
          timeAgo: timeAgo(f.createdAt), status: null,
        })),
      ];

      return activity.sort((a, b) => 0).slice(0, 10);
    }),
  }),
  // ─── Media (Images + Videos) ────────────────────────────────────────────
  media: router({
    // List all media (or filter by type)
    list: protectedProcedure
      .input(z.object({ type: z.enum(["image", "video"]).optional() }))
      .query(async ({ ctx, input }) => {
        return db.getUserMediaItems(ctx.user.id, input.type);
      }),

    // AI Image Generation
    generateImage: protectedProcedure
      .input(z.object({
        prompt: z.string().min(1).max(1000),
        style: z.enum(["photorealistic", "artistic", "anime", "sketch", "cinematic", "abstract"]).optional(),
        aspectRatio: z.enum(["1:1", "16:9", "9:16", "4:3", "3:4"]).optional(),
        originalImageUrl: z.string().url().optional(), // for image editing
      }))
      .mutation(async ({ ctx, input }) => {
        // Build an enhanced prompt with style
        const styleHints: Record<string, string> = {
          photorealistic: "photorealistic, high detail, 8k, professional photography",
          artistic: "digital art, vibrant colors, artistic, painterly",
          anime: "anime style, cel shading, manga art",
          sketch: "pencil sketch, hand-drawn, black and white",
          cinematic: "cinematic, dramatic lighting, film grain, movie still",
          abstract: "abstract art, geometric shapes, surreal, avant-garde",
        };
        const styleTag = input.style ? `, ${styleHints[input.style]}` : "";
        const enhancedPrompt = `${input.prompt}${styleTag}`;

        const originalImages = input.originalImageUrl
          ? [{ url: input.originalImageUrl, mimeType: "image/jpeg" }]
          : undefined;

        const { url } = await generateImage({ prompt: enhancedPrompt, originalImages });
        if (!url) throw new Error("Image generation failed: no URL returned");

        const fileKey = `media/${ctx.user.id}/images/${nanoid()}.png`;
        const item = await db.addMediaItem({
          userId: ctx.user.id,
          type: "image",
          source: "generated",
          prompt: input.prompt,
          url,
          fileKey,
          mimeType: "image/png",
          size: 0,
          style: input.style,
          aspectRatio: input.aspectRatio || "1:1",
          status: "completed",
        });
        return item;
      }),

    // AI Video Generation (generates a sequence of images as a video storyboard)
    generateVideo: protectedProcedure
      .input(z.object({
        prompt: z.string().min(1).max(1000),
        style: z.enum(["photorealistic", "artistic", "anime", "cinematic", "abstract"]).optional(),
        duration: z.enum(["short", "medium"]).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Step 1: Use LLM to generate a detailed visual prompt for the video keyframe
        const llmRes = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "You are a creative video director. Given a video concept, generate a single vivid, detailed prompt for the most impactful keyframe of the video. Focus on composition, lighting, and visual storytelling. Return ONLY the image prompt, no explanation."
            },
            { role: "user", content: `Video concept: ${input.prompt}\nStyle: ${input.style || "cinematic"}` }
          ]
        });
        const keyframePrompt = llmRes.choices?.[0]?.message?.content || input.prompt;

        // Step 2: Generate the keyframe image
        const styleHints: Record<string, string> = {
          photorealistic: "photorealistic, cinematic, 8k",
          artistic: "digital art, vibrant, painterly",
          anime: "anime style, dynamic, cel shading",
          cinematic: "cinematic, dramatic lighting, film still, widescreen",
          abstract: "abstract, surreal, motion blur",
        };
        const styleTag = input.style ? `, ${styleHints[input.style]}` : ", cinematic";
        const { url } = await generateImage({ prompt: `${keyframePrompt}${styleTag}, motion blur, dynamic composition` });
        if (!url) throw new Error("Video keyframe generation failed");

        const fileKey = `media/${ctx.user.id}/videos/${nanoid()}.png`;
        const item = await db.addMediaItem({
          userId: ctx.user.id,
          type: "video",
          source: "generated",
          prompt: input.prompt,
          url,           // keyframe image serves as the video preview
          thumbnailUrl: url,
          fileKey,
          mimeType: "image/png",
          size: 0,
          style: input.style,
          aspectRatio: "16:9",
          status: "completed",
        });
        return item;
      }),

    // User Upload (image or video)
    upload: protectedProcedure
      .input(z.object({
        filename: z.string(),
        mimeType: z.string(),
        size: z.number(),
        base64Data: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const isVideo = input.mimeType.startsWith("video/");
        const isImage = input.mimeType.startsWith("image/");
        if (!isVideo && !isImage) throw new Error("Only image and video files are supported");

        const ext = input.filename.split(".").pop() || "bin";
        const fileKey = `media/${ctx.user.id}/${isVideo ? "videos" : "images"}/${nanoid()}.${ext}`;
        const buffer = Buffer.from(input.base64Data, "base64");
        const { url } = await storagePut(fileKey, buffer, input.mimeType);

        const item = await db.addMediaItem({
          userId: ctx.user.id,
          type: isVideo ? "video" : "image",
          source: "uploaded",
          url,
          thumbnailUrl: isVideo ? undefined : url,
          fileKey,
          mimeType: input.mimeType,
          size: input.size,
          filename: input.filename,
          status: "completed",
        });
        return item;
      }),

    // Delete media item
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteMediaItem(input.id);
        return { success: true };
      }),
  }),

  // ─── Admin ──────────────────────────────────────────────────────
  admin: router({
    stats: adminProcedure.query(async () => {
      const dbInstance = await db.getDb();
      if (!dbInstance) return { users: 0, conversations: 0, tasks: 0, files: 0 };

      // Simple counts
      const { users: usersTable, conversations: convsTable, tasks: tasksTable, files: filesTable } = await import("../drizzle/schema");
      const { sql } = await import("drizzle-orm");

      const [userCount] = await dbInstance.select({ count: sql<number>`count(*)` }).from(usersTable);
      const [convCount] = await dbInstance.select({ count: sql<number>`count(*)` }).from(convsTable);
      const [taskCount] = await dbInstance.select({ count: sql<number>`count(*)` }).from(tasksTable);
      const [fileCount] = await dbInstance.select({ count: sql<number>`count(*)` }).from(filesTable);

      return {
        users: userCount?.count || 0,
        conversations: convCount?.count || 0,
        tasks: taskCount?.count || 0,
        files: fileCount?.count || 0,
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;
